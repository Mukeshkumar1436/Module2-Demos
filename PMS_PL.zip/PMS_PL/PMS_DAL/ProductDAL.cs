﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities;
using PMS_Exceptions;

namespace PMS_DAL
{
    public class ProductDAL
    {
        List<Product> products = new List<Product>();

        public List<Product> SelectAll()
        {
            return products;
        }

        public void Insert (Product product)
        {
            try
            {
                products.Add(product);
            }
            catch(Exception ex)
            {
                throw;
            }
            
        }
        public void Update(Product product)
        {
            try
            {
                ////1.LinQ Expression
                //var prd = (from p in products
                //          where p.Id == product.Id
                //          select p).SingleOrDefault();

                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                //2. Extension method & lambda
                var prd = products.SingleOrDefault(p => p.Id == product.Id);
                if (prd != null)
                {
                    prd.Name = product.Name;
                    prd.Price = product.Price;
                    prd.ExpDate = product.ExpDate;
                }
                else
                {
                    throw new ProductNotFoundException("Product with Id: " + product.Id + " Not found");
                }
                

                
            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch(Exception ex2)
            {
                throw;
            }
           

        }
        public void Delete(int id)
        {
            try
            {
                var prd = products.SingleOrDefault(p => p.Id == id);
                if (prd != null)
                {
                    products.Remove(prd);
                    Console.WriteLine("Record Deleted..");
                }
                else
                {
                    throw new ProductNotFoundException("Product with Id: " + id + " Not found");
                }



            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex2)
            {
                throw;
            }
        }
        public Product Find(int id)
        {
            try
            {
                
                var prd = products.SingleOrDefault(p => p.Id == id);
               
                if (prd != null)
                {
                    return prd;
                    //    foreach (var item in products)
                    //    {
                    //        Console.WriteLine(item);
                    //    }
                }
                else
                {
                    throw new ProductNotFoundException("Product with Id: " + id + " Not found");
                }



            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex2)
            {
                throw;
            }
        }
    }
}
