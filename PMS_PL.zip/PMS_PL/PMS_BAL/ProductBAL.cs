﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities;
using PMS_Exceptions;
using PMS_DAL;
using System.Text.RegularExpressions;

namespace PMS_BAL
{
    public class ProductBAL
    {
        ProductDAL dal = new ProductDAL();
        public bool IsValid(Product product)
        {
            bool valid = true;
            StringBuilder stringBuilder = new StringBuilder();
            
            if(!Regex.IsMatch(product.Email, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
            {
                valid = false;
                stringBuilder.Append("This is invalid Email Address"+Environment.NewLine);
            }
            if(!valid)
            {
                throw new ProductValidationException(stringBuilder.ToString());
            }

            return valid;
        }

        public List<Product> GetAll()
        {
            return dal.SelectAll();
        }

        public void Add(Product product)
        {
            try
            {
                 if(IsValid(product))
                {
                    dal.Insert(product);
                }
                
            }
            catch(ProductValidationException ex)
            {
                throw ex;
            }
            catch(Exception )
            {
                throw;
            }
        }
        public void Edit(Product product)
        {
            try
            {
                if (IsValid(product))
                {
                    dal.Update(product);
                }

            }
            catch (ProductValidationException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void del(int id)
        {
            try
            {
                 dal.Delete(id);               
            }
            catch (ProductNotFoundException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Product search(int id)
        {
            try
            {
                
                  return dal.Find(id);
               

            }
            catch (ProductValidationException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
