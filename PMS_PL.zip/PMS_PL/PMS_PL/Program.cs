﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_BAL;
using PMS_Entities;
using PMS_Exceptions;

namespace PMS_PL
{
    class Program
    {
    

        static Product CreateProduct()
        {
            Product product = new Product();
            Console.WriteLine("Enter Product Details");
            Console.WriteLine("Name: ");
            product.Name = Console.ReadLine();
            Console.WriteLine("Email: ");
            product.Email = Console.ReadLine();
            Console.WriteLine("Price: ");
            product.Price = double.Parse(Console.ReadLine());
            Console.WriteLine("Date: ");
            product.ExpDate = DateTime.Parse(Console.ReadLine());

            
            return product;

            
        }
        static void DisplayProducts(List<Product> prods)
        {
             foreach (var prd in prods)
            {
                Console.WriteLine(prd);
            }
            
        }

        static void Main(string[] args)
        {
            try
            {

            
            ProductBAL bal = new ProductBAL();
            string a;
            do
            {
                int choice = PrintMenu();
            Product prod;
          
               

                switch (choice)
                {

                    case 1:
                        prod = CreateProduct();
                        bal.Add(prod);
                        Console.WriteLine("Product Added");
                        break;
                    case 2:
                        prod = CreateProduct();
                        Console.WriteLine("Enter Product ID");
                        prod.Id = int.Parse(Console.ReadLine());
                        bal.Edit(prod);
                        Console.WriteLine("Product updated");
                        break;
                    case 3:
                        Console.WriteLine("Enter Prodcut Id: ");
                        int id = int.Parse(Console.ReadLine());
                        Console.WriteLine("Product Deleted");
                        bal.del(id);
                        break;
                    case 4:
                        List<Product> Prods = bal.GetAll();
                        DisplayProducts(Prods);

                        break;
                    case 5:
                        Console.WriteLine("Enter Id: ");
                        int Id = int.Parse(Console.ReadLine());
                        prod = bal.search(Id);
                        Console.WriteLine(prod);
                        break;
                    default: Console.WriteLine("Invalid Choice"); break;

                }
                
                Console.WriteLine("Enter y to continue");
                a = Console.ReadLine();
                //if (a == "y" || a == "Y")
                    
                
            } while (a == "y" || a=="Y");
            Console.ReadKey();
            PrintMenu();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();

        }
         static int PrintMenu()
        {
            Console.WriteLine("============Menu===========\n 1.Add Product \n 2. Update Product \n 3.Delete Product \n 4.Display Products \n 5.Search Product ");
            Console.WriteLine("Select Your Choice : ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
    }
}
