﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    public delegate void dele(int a, int b);

    class Program
    {
        public void area(int l, int b);

    
        static void Main(string[] args)
        {
        }
    }
}
