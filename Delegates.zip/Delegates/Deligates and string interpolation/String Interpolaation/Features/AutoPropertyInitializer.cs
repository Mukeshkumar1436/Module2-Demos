﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static Features.Projects;

namespace Features
{
    class AutoPropertyInitializer
    {
        static void Main(string[] args)
        {

            Projects project = new Projects();
            WriteLine($"Poject Id:   {project.ProjectId} \nProject Name:  { project.ProjectName}");
            ReadKey();
        }
    }
    public class Projects
    {
        /* Property with inline initialization */
        public int ProjectId { get; set; } = 1001;

        /* Getter only property with inline initialization */
        public string ProjectName { get; } = "Bank Of Chennai";
    }
}
