﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using static System.Console;

//namespace Features
//{
//    class UsingStringInterPolation
//    {
//        private static void Main(string[] args)
//        {
//            int ProjectId = 1001;
//            string ProjectName = "Bank Of Chennai";

//            WriteLine($"Project Id: {ProjectId} \n Project Name: {ProjectName}");
//        }

//    }
   
//}
