﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using static System.Console;
//using static Features.Project;

//namespace Features
//{
//    class UsingStatic
//    {
//        static void Main(string[] args)
//        {
//            ProjectId();
//            ProjectName();
//            ReadKey();

//        }
//    }
//    public class Project
//    {
//        public static void ProjectId()
//        {
//            WriteLine(" Project Id:");
//            ReadLine();

//        }
//        public static void ProjectName()
//        {
//            WriteLine(" Project Name:");
//            ReadLine();

//        }

//    }
//}
