﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeDelegate
{
    public delegate void practice(int a, int b);

    public class Program
    {
        public void Area(int l, int b) =>          //Lamba Expression
        
            Console.WriteLine("Area :{0}", l * b);
        
        public void Perimeter(int l, int b)
        {
            Console.WriteLine($"Perimeter :{2 * (l+b)}");         //String Interpolation
        }
        public Program()
        {
            Console.WriteLine("Rakesh");
        }
        static void Main(string[] args)
        {
            //new program();   //Anonymous Method
            Program obj = new Program();
            practice obj1 = new practice(obj.Area);
            //practice obj2 = new practice(obj.Perimeter);
            obj1 += obj.Perimeter;
            obj1.Invoke(10, 20);
            Console.ReadKey();
        }
    }
}
