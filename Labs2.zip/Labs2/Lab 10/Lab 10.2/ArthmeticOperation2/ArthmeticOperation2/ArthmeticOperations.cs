﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArthmeticOperation2
{

    delegate void MyDelegate(int a, int b);
    class ArithematicOperations
        {

            public static void Add(int a, int b)
            {
            Console.WriteLine( a + b);
            }
            public static void Sub(int a, int b)
            {
                Console.WriteLine(a - b);
            }
            public static void Div(int a, int b)
            {
                 Console.WriteLine(a / b);
             }
            public static void Mul(int a, int b)
            {
                    Console.WriteLine(a * b);
            }
            public static void Max(int a, int b)
            {
                if (a > b)
                {
                        Console.WriteLine(a );
                }
                else
                {
                     Console.WriteLine(b);
                }
            }
            
            
            public static void PerformArithmeticOperation(int a, int b, MyDelegate arOperation)
            {

                arOperation(a, b);

            }


     }


        
}
