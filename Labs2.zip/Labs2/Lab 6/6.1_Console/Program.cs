﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._1_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            try

            {

                Customer cust = new Customer();

                Console.WriteLine("custommerID:");

                cust.CustId = int.Parse(Console.ReadLine());

                Console.WriteLine("customer name: ");

                cust.CustName = Console.ReadLine();

                Console.WriteLine("address : ");

                cust.Address = Console.ReadLine();

                Console.WriteLine("city: ");

                cust.City = Console.ReadLine();

                Console.WriteLine("phone : ");

                cust.Phone = int.Parse(Console.ReadLine());

                Console.WriteLine("credit limit : ");

                cust.CreditLimit = double.Parse(Console.ReadLine());

                if (cust.CreditLimit > 50000)

                {

                    throw new CreditLimitException("limit is exceeded");

                }

                else

                {

                    Console.WriteLine("OK");

                }

            }

            catch (CreditLimitException ce)

            {

                Console.WriteLine(ce.Message);

            }

            Console.ReadLine();

        }
    }

    class Customer

    {

        int customerId;

        string customerName;

        string address;

        string city;

        int phone;

        double creditLimit;

        public int CustId
        {
            get { return customerId; }

            set { customerId = value; }

        }

        public string CustName

        {

            get { return customerName; }

            set { customerName = value; }

        }

        public string Address

        {

            get { return address; }

            set { address = value; }

        }

        public string City

        {

            get { return city; }

            set { city = value; }

        }

        public int Phone

        {

            get { return phone; }

            set { phone = value; }

        }

        public double CreditLimit

        {

            get { return creditLimit; }

            set { creditLimit = value; }

        }

        public Customer()

        {

        }

        public Customer(int id, string name, string address, string city, int phn, double crelimit)

        {

            this.customerId = id;

            this.customerName = name;

            this.address = address;

            this.city = city;

            this.phone = phn;

            this.creditLimit = crelimit;

        }

    }




    public class CreditLimitException : ApplicationException

    {

        public CreditLimitException() : base() { }




        public CreditLimitException(string message) : base(message) { }




        public CreditLimitException(string message, Exception innerException) : base(message, innerException) { }




    }

}

    

