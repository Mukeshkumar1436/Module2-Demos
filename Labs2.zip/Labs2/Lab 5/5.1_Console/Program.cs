﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _5._1_Console
{
    public enum BankAccountTypeEnum { Current = 1, Saving = 2 }


    public interface IBankAccount
    {
        double GetBalance();
        double CalculateInterest();
        void Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);
        BankAccountTypeEnum AccountType { get; set; }
    }

    class Program
    {

        static void Main(string[] args)
        {

              

         
            Console.WriteLine("WELCOME TO ICICI BANK");
          
            ICICI icbank = new ICICI();

                
            icbank.BankAccountTypeEnum = BankAccountTypeEnum.Saving;

            
            Console.WriteLine("\n8000 Rs are deposited into Saving Account");
            icbank.Deposit(8000);

          
            ICICI icbank1 = new ICICI();

              
            icbank1.BankAccountTypeEnum = BankAccountTypeEnum.Current;

            
            Console.WriteLine("20000 Rs are deposited into Current Account");
            icbank1.Deposit(20000);

          
            Console.WriteLine("Balance of ICICI bank saving account : " + icbank.GetBalance());
            Console.WriteLine("Balance of ICICI bank current account : " + icbank1.GetBalance());

          
            Console.WriteLine("5000 Rs transfered from Saving Acc to Current Acc");
            icbank.Transfer(icbank1, 5000);

          
            Console.WriteLine("\nNew balance after transaction");
            Console.WriteLine("Balance of ICICI bank saving account : " + icbank.GetBalance());
            Console.WriteLine("Balance of ICICI bank current account : " + icbank1.GetBalance());

            Console.WriteLine("\nBalance with calculated Tax");
            Console.WriteLine("Balance of ICICI bank saving account including tax : " + icbank.CalculateInterest());
            Console.WriteLine("Balance of ICICI bank current account ncluding tax : " + icbank1.CalculateInterest());

            
           
            Console.WriteLine("WELCOME TO HSBC BANK");
          

            HSBC hs = new HSBC();
            HSBC hs1 = new HSBC();

            hs.BankAccountTypeEnum = BankAccountTypeEnum.Current;
            hs1.BankAccountTypeEnum = BankAccountTypeEnum.Current;

            Console.WriteLine("\n40000 Rs are deposited into Saving Account");
            hs.Deposit(40000);
            Console.WriteLine("Balance of HSBC bank saving account : " + hs.GetBalance());
            Console.WriteLine("Balance of HSBC bank current account : " + hs1.GetBalance());

          
            Console.WriteLine("30000 Rs transfered from Saving Acc to Current Acc");
            hs.Transfer(hs1, 30000);

            Console.WriteLine("\nNew balance after transaction");
            Console.WriteLine("Balance of HSBC bank saving account : " + hs.GetBalance());
            Console.WriteLine("Balance of HSBC bank current account : " + hs1.GetBalance());

            Console.WriteLine("\nBalance with calculated Tax");
            Console.WriteLine("Balance of HSBC bank saving account including tax : " + hs.CalculateInterest());
            Console.WriteLine("Balance of HSBC bank current account ncluding tax : " + hs1.CalculateInterest());
            Console.WriteLine("***********************************************************");
            Console.ReadLine();
        }
    }

    abstract class BankAccount : IBankAccount
    {
        protected double balance;

        public BankAccountTypeEnum AccountType
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }

        abstract public double CalculateInterest();

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }

        abstract public double GetBalance();

        abstract public bool Transfer(IBankAccount toAccount, double amount);

        public virtual bool Withdraw(double amount)
        {
            balance = balance - amount;
            return true;
        }
    }

    class ICICI : BankAccount
     
    {
        public object BankAccountTypeEnum { get; internal set; }
        double total;

        public override bool Withdraw(double amount)
        {
            if ((balance - amount) >= 0)
            {
                base.Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("Sorry Insufficient balance");
                return false;
            }

           
        }

        public override bool Transfer(IBankAccount toAccount, double amount)    
        {
            if ((balance - amount) >= 1000)
            {
                toAccount.Deposit(amount);
                Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("Sorry Insufficient balance");
                return false;
            }

              
        }

        public override double GetBalance()
        {
            return balance;
        }

        public override double CalculateInterest()
        {
            balance = GetBalance();
            total = balance + ((balance * 7 * 1) / 100);
            return total;
        }
    }

    class HSBC : BankAccount     
    {
        public BankAccountTypeEnum BankAccountTypeEnum { get; internal set; }
        double total;

        public override bool Withdraw(double amount)
        {
            if ((balance - amount) >= 0)
            {
                base.Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("Sorry Insufficient balance");
                return false;
            }

           
        }

        public override bool Transfer(IBankAccount toAccount, double amount)     
        {
            if ((balance - amount) >= 1000)
            {
                toAccount.Deposit(amount);
                Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("Sorry Insufficient balance");
                return false;
            }
              
        }

        public override double GetBalance()
        {
            return balance;
        }

        public override double CalculateInterest()
        {
            balance = GetBalance();
            total = balance + ((balance * 7 * 1) / 100);
            return total;
        }
    }
}  

