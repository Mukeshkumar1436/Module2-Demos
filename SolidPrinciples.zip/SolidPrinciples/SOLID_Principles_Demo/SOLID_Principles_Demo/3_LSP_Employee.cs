﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Principles_Demo.LSP //Liskov substitution principle
{
    //Child class should not break parent class’s type definition and behavior.
    public abstract class Employee
    {
        public abstract string GetProjectDetails(int employeeId);    
        public abstract string GetEmployeeDetails(int employeeId);      
    }
    public class CasualEmployee : Employee
    {
        public override string GetProjectDetails(int employeeId)
        {
            return "Casual Employee Project Details";
        }
        public override string GetEmployeeDetails(int employeeId)
        {
            return "Casual Employee Details";
        }
    }
    public class ContractualEmployee : Employee
    {
        public override string GetProjectDetails(int employeeId)
        {
            return "Contractual Employee Project Details";
        }

        // May be for contractual employee we do not need to store the details into database.
        public override string GetEmployeeDetails(int employeeId)
        {
            throw new NotImplementedException();
        }
    }

    class LSP_Test
    {       
        static void Main(string[] args)
        {
            ////Improper version
            //List<Employee> employeeList = new List<Employee>();
            //employeeList.Add(new ContractualEmployee());
            //employeeList.Add(new CasualEmployee());
            //foreach (Employee e in employeeList)
            //{
            //    e.GetEmployeeDetails(1245);
            //}

            //Proper version
            //List<Employee> employeeList = new List<Employee>();
            //employeeList.Add(new ContractualEmployee1());
            //employeeList.Add(new CasualEmployee1());
            //foreach (Employee e in employeeList)
            //{
            //    e.GetEmployeeDetails(1245);
            //}

            Console.ReadKey();
        }
    }





















    public interface IEmployee
    {
        string GetEmployeeDetails(int employeeId);
    }
    public interface IProject
    {
        string GetProjectDetails(int employeeId);
    }
    public class CasualEmployee1 : IEmployee, IProject
    {
        public string GetProjectDetails(int employeeId)
        {
            return "Casual Employee Project Details";
        }
        public string GetEmployeeDetails(int employeeId)
        {
            return "Casual Employee Details";
        }
    }
    public class ContractualEmployee1 : IProject
    {      
        public string GetProjectDetails(int employeeId)
        {
            return "Contractual Employee Project Details";
        }
    }

}