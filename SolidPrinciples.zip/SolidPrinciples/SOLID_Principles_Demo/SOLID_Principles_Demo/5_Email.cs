﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Principles_Demo.DIP //Dependency inversion principle
{
    /*This principle tells you not to write any tightly coupled code because it creates many 
    complications when time comes to maintain the application when the application is growing bigger
    and bigger. If a class depends on another class, then we need to change one class if something 
    changes in that dependent class. We should always try to write loosely coupled class */
    public class Email1
    {
        public void SendEmail()
        {
            // code to send mail
        }
    }   
    public class Notification1
    {
        private Email1 _email;
        public Notification1()
        {
            _email = new Email1();
        }

        public void PromotionalNotification()
        {
            _email.SendEmail();
        }
    }






    //Step-2 : 
    public interface IMessenger
    {
        void SendMessage();
    }
    public class Email2 : IMessenger
    {
        public void SendMessage()
        {
            // code to send email
        }
    }

    public class SMS : IMessenger
    {
        public void SendMessage()
        {
            // code to send SMS
        }
    }
    public class Notification2
    {
        private IMessenger _iMessenger;
        public Notification2()
        {
            _iMessenger = new Email2();
        }
        public void DoNotify()
        {
            _iMessenger.SendMessage();
        }
    }

    //Step-3
    public class Notification3
    {
        private IMessenger _iMessenger;
        public Notification3(IMessenger pMessenger)
        {
            _iMessenger = pMessenger;
        }
        public void DoNotify()
        {
            _iMessenger.SendMessage();
        }
    }


}
