﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SOLID_Principles_Demo.SRP;

namespace SOLID_Principles_Demo.OCP //Open closed principle 
{    
    public interface IReportGeneration
    {
        void GenerateReport(Employee em);        
    }
   
    public class CrystalReportGeneraion : IReportGeneration
    {
        public void GenerateReport(Employee em)
        {
            // Generate crystal report.
        }
    }
 
    public class PDFReportGeneraion : IReportGeneration
    {
        public void GenerateReport(Employee em)
        {
            // Generate PDF report.
        }
    }

    public class ExcelReportGeneraion : IReportGeneration
    {
        public void GenerateReport(Employee em)
        {
            // Generate PDF report.
        }
    }
}
