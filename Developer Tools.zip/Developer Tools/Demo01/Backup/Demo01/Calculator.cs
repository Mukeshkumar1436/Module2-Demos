using System;
using System.Collections.Generic;
using System.Text;

namespace Demo01
{
    public class Calculator
    {
        public int AddNumbers(int a, int b)
        {
            return a + b;
        }

        public int SubtractNumbers(int a, int b)
        {
            return a - b;
        }

        public int MultiplyNumbers(int a, int b)
        {
            return a * b;
        }

        public int DivideNumbers(int a, int b)
        {
            int res;
            try
            {
                res = a / b;
            }
            catch(DivideByZeroException)
            {
                throw;
            }
           
            return res;
        }
    }
}
