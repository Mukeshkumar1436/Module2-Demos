﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Namespace for working with log4net
using log4net;
using log4net.Config;
using log4net.Layout;
using System.Xml;
using log4net.Core;
using System.Reflection;
namespace Log4NetDemo
{
    public class Sample
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Sample));

        static void Main(string[] args)
        {
            //This calls the default configurator for log4net
            XmlConfigurator.Configure();

            log.Info("Entering application.");

            for (int counter = 1; counter <= 10; counter++)
            {
                log.DebugFormat("Inside of the loop (Counter = {0})", counter);
            }

            try
            {
                throw new NotImplementedException("Testing log4net");

            }
            catch (NotImplementedException ex)
            {
                log.Fatal(ex.Message);
            }

            log.Info("Exiting application.");
        }

    }

    public class MyXmlLayout : XmlLayoutBase
    {
        protected override void FormatXml(XmlWriter writer, LoggingEvent loggingEvent)
        {
            writer.WriteStartElement("LogEntry");
            writer.WriteStartElement("Message");
            writer.WriteString(loggingEvent.RenderedMessage);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }
    }
}
