﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FxCopSample
{
    public abstract class Account
    {
        public int AccountNo { get; set; }
        public string CName { get; set; }

        public static void GetDetails() { }// define as abstract

        interface IPrintable
        {
        
        }

    }
    public abstract class Saving : Account
    {
         
              
        public int MinBal { get;set; }

        
    
    }

}
