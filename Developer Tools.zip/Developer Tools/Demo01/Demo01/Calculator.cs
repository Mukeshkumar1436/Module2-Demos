using System;
using System.Collections.Generic;
using System.Text;

namespace Demo01
{
    /// <summary>
    /// Author:Sangeetha
    /// Desc: To test the Calc Class
    /// DoC:8-Sep-2017
    /// </summary>
    public class Calculator
    {
        public int AddNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public int SubtractNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public int MultiplyNumbers(int a, int b)
        {
             return a * b;
        }

        public int DivideNumbers(int a, int b)
        {
            int res;
            try
            {
                res = a / b;
            }
            catch (DivideByZeroException)
            {
                throw;
            }
           
            return res;
        }
    }
}
