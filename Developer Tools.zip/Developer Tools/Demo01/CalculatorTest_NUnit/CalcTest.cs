﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Demo01;

namespace CalculatorTest_NUnit
{
    [TestFixture ]
    public class CalcTest
    {
        Calculator calcObj;
        [SetUp]////Method to be called everytime before the Testcase is executed
        [TestFixtureSetUp]////Method to be called once before any of the Testcase is executed
         public void Init()
        {
          calcObj = new Calculator();
        }

        [Test]
        public void SumTest()
        {
           
            int expectedResult = 10;
            int actualResult = calcObj.AddNumbers(5, 5);
            Assert.AreEqual(expectedResult, actualResult);
        }
        [Test]
        public void ProductTest()
        {
         
            int expectedResult = 0;
            int actualResult = calcObj.SubtractNumbers(15, 5);
            Assert.AreEqual(expectedResult, actualResult);
        
        }
        [Test]
        public void DivisionTest()
        {

            int expectedResult = 10;
            int actualResult = calcObj.DivideNumbers (150, 15);
            Assert.AreEqual(expectedResult, actualResult);

        }
       
        [Test]
        [ExpectedException(typeof(DivideByZeroException))]
        public void DivisionExceptionTest()
        {
                
            int actualResult = calcObj.DivideNumbers(150, 0);
  
        }

        [Ignore]
        [Test]
        public void DifferenceTest()
        {
           
            int expectedResult = 10;
            int actualResult = calcObj.SubtractNumbers(15, 5);
            Assert.AreEqual(expectedResult, actualResult);

        }
        [TearDown] //Method to be called everytime after the Testcase is executed
        [TestFixtureTearDown]////Method to be called once after all the Testcases are executed
            public void Destruct()
        {
            calcObj = null;
        }


    }
}
