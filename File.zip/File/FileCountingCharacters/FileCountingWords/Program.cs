﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Demo
{
    public static void Main()
    {
        string path = File.ReadAllText(@"C:\\govi\gov.txt");

        Console.WriteLine(path); // it ll display ur file on console

        Console.Write(path.Length); // show character
        Console.WriteLine();

        Console.WriteLine(path.Split('\r').Length);  // total line

        Console.WriteLine(path.Split(' ').Length); // total word

        Console.ReadKey();
    }

}