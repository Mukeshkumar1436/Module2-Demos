﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    class Student
    {
        int RollNo;
        string name;
        double feespaid;
        DateTime dob;

        public Student(int RollNo, String name, double feespaid, DateTime dob)
        {
            this.RollNo = RollNo;
            this.name = name;
            this.feespaid = feespaid;
            this.dob = dob;
        }
        public string GetStudentDetails()
        {
            return "rollno: " + RollNo + " name: " + name + " feespaid: " + feespaid + " dob: " + dob;
        }
    }
}
