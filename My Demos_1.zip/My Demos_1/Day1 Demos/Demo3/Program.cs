﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter RollNo: ");
            int rno = int.Parse(Console.ReadLine());
            Console.Write("Enter Name: ");
            string nm = Console.ReadLine();
            Console.Write("Enter feespaid: ");
            double fp = double.Parse(Console.ReadLine());
            Console.Write("Enter dob: ");
            DateTime dob = DateTime.Parse(Console.ReadLine());

            Student student = new Student(rno,nm,fp,dob);
            Console.Write(student.GetStudentDetails());
            Console.ReadKey();
        }
    }
}
