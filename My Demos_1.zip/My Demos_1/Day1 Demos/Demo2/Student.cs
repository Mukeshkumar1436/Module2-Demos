﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Student
    {
        int RollNo;
            string name;
        double feespaid;
        DateTime dob;

        public Student(int RollNo, String name, double feespaid, DateTime dob)
        {
            this.RollNo = RollNo;
            this.name = name;
            this.feespaid = feespaid;
            this.dob = dob;
        }
        public string getstudentdetails()
        {
            return "rollno"+RollNo+, "name"+name
        }
    }
}
