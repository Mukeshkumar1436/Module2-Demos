﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mukesh
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter RollNo: ");
            int rno = int.Parse(Console.ReadLine());
            Console.Write("Enter Name: ");
            string nm = Console.ReadLine();
            Console.Write("Enter feespaid: ");
            double fp = double.Parse(Console.ReadLine());
            Console.Write("Enter dob: ");
            DateTime dob = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("1.UnderGraduate, 2.Graduate, 3.PostGraduate");
            HighestQualification qual = (HighestQualification)int.Parse(Console.ReadLine());


            student student = new student(rno, nm, fp, dob, qual);
            Console.Write(student.GetstudentDetails());
            Console.ReadKey();
        }
    }
}
