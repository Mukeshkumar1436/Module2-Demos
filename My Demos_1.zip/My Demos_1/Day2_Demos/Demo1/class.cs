﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public enum HighestQualification { UnderGraduate = 1, Graduate, PostGraduate };
    class student
    {
        int rollno;
        string name;
        double feespaid;
        DateTime dob;
        HighestQualification qual;


        public student(int rollno, string name, double feespaid, DateTime dob, HighestQualification qual)
        {
            this.rollno = rollno;
            this.name = name;
            this.feespaid = feespaid;
            this.dob = dob;
            this.qual = qual;
        }

        public string GetstudentDetails()
        {
            return "rollno :" + rollno + " Name :" + name + " Fesspaid:" + feespaid + " Date of Birth:" + dob + " Highest Qualification:" + qual;
        }
    }
}



