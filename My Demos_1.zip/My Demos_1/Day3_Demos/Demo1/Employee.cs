﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Employee
    {
        protected int empId;
        protected string empName;
        protected double salary, gs, ns, pf;
       

        public Employee(int empId, string empName, double salary)
        {
            this.empId = empId;
            this.empName = empName;
            this.salary = salary;
        }

       
    }
    class Manager: Employee
        {
        public Manager(int empId, string empName, int salary)
            : base(empId, empName, salary)
        {

        }

    }
}
