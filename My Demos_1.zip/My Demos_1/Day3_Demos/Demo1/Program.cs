﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee manager = new Manager(172435, "Mukesh", 20000);

            Console.ReadKey();
        }
    }
}
