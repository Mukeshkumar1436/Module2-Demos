﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myassembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type[] types = myassembly.GetTypes();

            Console.WriteLine("Number of Types : " + types.Length);
            foreach (Type t in types)
            {
                Console.WriteLine($"Name : {t.Name}");
                Console.WriteLine($"Assembly Qualified Name : {t.AssemblyQualifiedName}");
                Console.WriteLine($"Contains Generic Parameters : {t.ContainsGenericParameters}");
                Console.WriteLine($"Full Name : {t.FullName}");
                Console.WriteLine($"Is Abstract : {t.IsAbstract}");
                Console.WriteLine($"Is Array : {t.IsArray}");
                Console.WriteLine($"Is Class : {t.IsClass}");
                Console.WriteLine($"Is Enum : {t.IsEnum}");
                Console.WriteLine($"Is Interface : {t.IsInterface}");
                Console.WriteLine($"Is Public : {t.IsPublic}");
                Console.WriteLine($"Is Value Type : {t.IsValueType}");
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
