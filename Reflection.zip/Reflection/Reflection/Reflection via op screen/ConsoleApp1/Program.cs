﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter assembly path:");
            string asmPath = Console.ReadLine();    // storing path

            Assembly asm = Assembly.LoadFrom(asmPath);  //calling by path

            foreach(Type type in asm.GetTypes())
            {

                Console.WriteLine("\n\nmethods from" + type.FullName);  //methods from Given Path   Class
                foreach (MethodInfo mi in type.GetMethods())
                {
                    Console.WriteLine(mi.ToString());
                }

                Console.WriteLine("\n\nproperties from" + type.FullName);   //properties from   Given Path  Class
                foreach (PropertyInfo pi in type.GetProperties())
                {
                    Console.WriteLine(pi.ToString());
                }


                Console.WriteLine("\n\nFields from" + type.FullName);   //Fields from   Given Path Class
                foreach (FieldInfo fi in type.GetFields())
                {
                    Console.WriteLine(fi.ToString());
                }
           
            }
            Console.ReadKey();
        }
    }
}
