﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
   public  class Manager
    {
      public  int ManagerId { get; set; }
      public  string ManagerName { get; set; }

        public void GetManagerDetails(int id,string name)
        {
            this.ManagerId = id;
            this.ManagerName = name;
        }
    }
}
