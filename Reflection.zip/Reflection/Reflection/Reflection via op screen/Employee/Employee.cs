﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Employee
    {
        public int empid { get; set; }

        public string empName { get; set; }

        public void GetEmployeeDetails(int Empid,string Empname)
        {
            this.empid = Empid;
            this.empName = Empname;
        }
    }
}
