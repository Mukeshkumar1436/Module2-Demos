﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Student
    {
        public int RollNo { get; set; }
        public string studName { get; set; }

        public void setStudentDetails(int rollNo, string studName)
        {
            this.RollNo = rollNo;
            this.studName = studName;
        }

    }
}
