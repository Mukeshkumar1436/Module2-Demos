﻿using SMS_Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/

namespace SMS_DAL
{
    public class StudentDAL
    {
        public static List<Student> studs = new List<Student>();
        public bool AddStudentDAL(Student student)
        {
            bool studentAdded = false;
            try
            {
                studs.Add(student);
                studentAdded = true;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return studentAdded;
        }
        public Student DisplayParticularStudentDAL(int rollNo)
        {
            try
            {
                Student displayedStudent = null;
                foreach (var student in studs)
                {
                    if (student.StudentId == rollNo)
                    {
                        displayedStudent = student;
                    }

                }
                return displayedStudent;
            }

            catch (Exception ex2)
            {
                throw ex2;
            }

        }
        ////public static List<Student> DisplayStudentFromFile(int studentid)
        ////{
        ////    Student Displaystudent = new Student();
        ////    try
        ////    {
                
        ////        foreach (var student in studs)
        ////        {
        ////            if (student.StudentId== studentid)
        ////            {

        ////                Displaystudent = student;
        ////            }

        ////        }
        ////        return studs;
        ////    }

        ////    catch (Exception ex2)
        ////    {
        ////        throw ex2;
        ////    }

        //}
        //Serializing data
        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"Student.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, studs);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        //deserializing data
        public static List<Student> DeserializeData()
        {
            FileStream stream = new FileStream(@"Student.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            studs = formatter.Deserialize(stream) as List<Student>;
            return studs;

        }

    }
}
