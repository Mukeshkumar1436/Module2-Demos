﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionBodiedFeature
{
    class Manager
    {
        //Defining and intializing AutoImplementing properties in Manager class 
        public int ManagerId { get; set; } = 1001;
        public string Name { get; set; } = "Suresh";
        
        //Implementing ExpressionBodyFeature

        public void print() => Console.WriteLine("Id : {0} Name : {1}", ManagerId, Name);

        static void Main(string[] args)
        {
            //Creating instance of manager class
            Manager m = new Manager();
            //By using instance of manager class invoke the print(); method
            m.print();
            Console.ReadLine();
        }
    }
}
