﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

/*Emp id:172304
    AuthorName:P.L.S.Supriya
    File:ReflectionEntity
    CreationDate:12-02-2019*/
namespace Reflection_Entity
{
    class Program
    {
        static void Main(string[] args)
        {

            Type t = typeof(SalesMan);
            //displaying and creating property information

            PropertyInfo[] property = t.GetProperties();

            Console.WriteLine($"Properties Information" + Environment.NewLine);

            foreach (PropertyInfo P in property)

            {

                Console.WriteLine("Prop Name : " + P.Name);

                Console.WriteLine("Prop PropertyType : " + P.PropertyType);

                Console.WriteLine("Prop Module : " + P.Module + Environment.NewLine);

            }
            // //displaying and creating Field information

            FieldInfo[] fi = t.GetFields();

            Console.WriteLine($"Fields Information" + Environment.NewLine);

            foreach (FieldInfo F in fi)

            {

                Console.WriteLine("Field Name : " + F.Name);

                Console.WriteLine("Field Module : " + F.Module);

                Console.WriteLine("Field ReflectedType : " + F.ReflectedType + Environment.NewLine);

            }
            // //displaying and creating constructor information

            ConstructorInfo[] CI= t.GetConstructors();

            Console.WriteLine($"Constructors Information" + Environment.NewLine);

            foreach (ConstructorInfo C in CI)

            {

                Console.WriteLine("Constructor Name : " + C.Name);

                Console.WriteLine("Constructor MethodHandle : " + C.MethodHandle);

                Console.WriteLine("Constructor IsStatic : " + C.IsStatic);

                Console.WriteLine("Constructor Module : " + C.Module + Environment.NewLine);

            }

        }
    }
}
