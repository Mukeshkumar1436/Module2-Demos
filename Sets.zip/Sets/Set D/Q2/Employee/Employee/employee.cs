﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class employee
    {
        //Properties For an Employee
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }

        //Creating Default Constructor 
        public employee()
        {

        }

        //creating Parameterized Constructor
        public employee(int eid,string ename,string gender,string dob)//Constructor Overloading
        {
            EmpId = eid;
            EmpName = ename;
            Gender = gender;
            DOB = dob;
        }

        //Creating Method For Displaying The Details
        public void DisplayDetails()
        {
            Console.WriteLine($"Employee ID:{EmpId}");
            Console.WriteLine($"Employee Name:{EmpName}");
            Console.WriteLine($"Employee Gender:{Gender}");
            Console.WriteLine($"Employee DateOfBirth:{DOB}");
        }
    }
}
