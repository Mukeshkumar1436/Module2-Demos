﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Object for an Employee using Parameterized Constructor
            employee e = new employee(101, "Siri", "Female","1996-3-20");

            //Invoking the Displaydetails() Method
            e.DisplayDetails();

            Console.ReadKey();
        }
    }
}
