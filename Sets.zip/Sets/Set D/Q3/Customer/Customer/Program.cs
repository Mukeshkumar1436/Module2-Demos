﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace customer
{
    class Program
    {
        List<customer> lc = new List<customer>();

        //Adding Customer Details 
        public void AddCustomer()

        {

            customer c = new customer();

            Console.WriteLine("Enter Customer Bill No:");
            c.BillNo = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter CustomerID:");
            c.CustomerID = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Customer name:");
            c.CustomerName = Console.ReadLine();

            Console.WriteLine("Enter Phone Number:");
            c.MobileNo = Console.ReadLine();

            Console.WriteLine("Enter Address:");
            c.Address = Console.ReadLine();

            Console.WriteLine("Enter EmailID:");
            c.Email = Console.ReadLine();

            Console.WriteLine("Enter Units Consumed:");
            c.UnitsConsumed = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Rate Per Unit:");
            c.Rate = int.Parse(Console.ReadLine());



            lc.Add(c);

            Choice();

        }


        //Displaying the customer Details
        public void displaylist()

        {
            try
            {

                if (lc.Count == 0 || lc == null)

                {

                    Console.WriteLine("No records");

                }

                else

                {

                    foreach (var cus in lc)

                    {
                        Console.WriteLine("Bill No:" + cus.BillNo);

                        Console.WriteLine("Customer ID:" + cus.CustomerID);

                        Console.WriteLine("Customer Name:" + cus.CustomerName);

                        Console.WriteLine("Customer phone number:" + cus.MobileNo);

                        Console.WriteLine("Customer Address:"+cus.Address);

                        Console.WriteLine("Customer Mail ID:"+cus.Email);

                        Console.WriteLine("Units Consumed:" + cus.UnitsConsumed);

                        Console.WriteLine("Rate Per Unit:" + cus.Rate);

                        cus.Amount = cus.UnitsConsumed * cus.Rate;
                        Console.WriteLine("Amount:" + cus.Amount);

                        cus.SurCharge = 5 * cus.Amount / 100;
                        Console.WriteLine("SurCharge: " + cus.SurCharge);

                        cus.GrossAmount = cus.Amount + cus.SurCharge;
                        Console.WriteLine(" GrossAmount:" + cus.GrossAmount);


                    }

                }
            } catch (CustomerNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            Choice();

        }



        public void Choice()

        {

            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine($"\n***********Customer{i} Details***********");

                Console.WriteLine("1. Add Customer");

                Console.WriteLine("2. Get all Customer Details");

                Console.WriteLine("Enter your choice");

                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:

                        displaylist();

                        break;


                }



               
            }


            }
            static void Main(string[] args)
            {
                new Program().Choice();

            Console.ReadKey();
            }
        }
    }


