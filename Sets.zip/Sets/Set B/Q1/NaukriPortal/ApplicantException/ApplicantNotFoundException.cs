﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NaukriException
{
  
        // Exception Class to catch the Exceptions occuring in Naukriportal
        //user defined exception
        [Serializable]
        public class ApplicantNotFoundException : Exception
        {
            //Default Constructor that inherits the base constructor
            public ApplicantNotFoundException() : base() { }
            //Parameterized constructor for passing the Exception Message
            public ApplicantNotFoundException(string message) : base(message) { }

        }
   
}
