﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NaukriEntity;
using NaukriException;
using Naukri_Bal;

namespace NaukriPortal
{
    class ApplicantPL
    {
        //displaying the applicant details which are added
        public static void AddStudent()
        {
            try
            { 
                Applicants applicant = new Applicants();
                Console.WriteLine("Enter Applicant Name :");
                 applicant.Name = Console.ReadLine();
                Console.WriteLine("Enter Applicant Qualification :");
                applicant.Qualification = Console.ReadLine();
                Console.WriteLine("Enter Applicant Mobile Number :");
                applicant.MobileNo = Console.ReadLine();
                Console.WriteLine("Enter Applicant City :");
                applicant.City = Console.ReadLine();
                Console.WriteLine("Enter Applicant DOB :");
                applicant.DOB = Convert.ToDateTime(Console.ReadLine());
                bool ApplicantAdded = ApplicantBal.AddApplicantBAL(applicant);
                if (ApplicantAdded == true)
                {
                  Console.WriteLine("Student Added Successfully");
                }
                else
                {
                   throw new ApplicantNotFoundException("Student not added");
                }
                ApplicantBal.SerializeData();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
         
        // searching applicants using their qualifications

        public static void SearchStudent()
        {
            string qualification;
            Applicants searchApplicant;
            try
            {
                Console.WriteLine("Enter qualification to Search:");
                qualification = Console.ReadLine();
                searchApplicant = ApplicantBal.SearchApplicantBAL(qualification);
                if (searchApplicant != null)
                {
                    Console.WriteLine("Applicant Name:" + searchApplicant.Name);
                    Console.WriteLine("Applicant Qualification" + searchApplicant.Qualification);
                    Console.WriteLine("Applicant mobile number" + searchApplicant.MobileNo);
                    Console.WriteLine("Applicant City" + searchApplicant.City);
                    Console.WriteLine("Applicant Date Of Birth " +searchApplicant.DOB);
                }
                else
                {
                    throw new ApplicantNotFoundException("Student not Found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("**********Naukri.com**********");
            Console.WriteLine("1.Add Student\n");
            Console.WriteLine("2.SearchStudent\n");
        }

        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                bool validChoice;
                Console.WriteLine("Enter your Choice Please:");
                validChoice = Int32.TryParse(Console.ReadLine(), out choice);

                if (!validChoice)
                    Console.WriteLine("Enter the choice 1 or 2");
                else
                {
                    switch (choice)
                    {
                        case 1:
                            AddStudent();
                            break;
                        case 2:
                            SearchStudent();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }


            } while (choice != 0);
            Console.ReadKey();

        }
    }
}
