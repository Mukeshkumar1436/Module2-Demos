﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NaukriEntity
{
    //Creating methods for performing operations on ApplicantEntity
    [Serializable]
    public class Applicants
    {
        //properties are used in the program
        public string Name { get; set; }
        public string Qualification { get; set; }
        public string MobileNo { get; set; }
        public string City { get; set; }
        public DateTime DOB { get; set; }

    }
}
