﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guest_Entities
{
    public enum Relation
    {
        father=1,mother,brother,sister,cousin,uncle,aunt,son,daughter,friend
    };
    public class Guest
    {
        public int GuestID { get; set; }
        public string GuestName { get; set; }
        public string ContactNo { get; set; }
        public Relation Relationship { get; set; }
        public Guest()
        {

        }
    }

}
