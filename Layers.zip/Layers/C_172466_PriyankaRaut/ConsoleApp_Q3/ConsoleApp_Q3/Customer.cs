﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Q3
{

    // Class customer inherits person class

    class Customer : Person
    {
        public string Address { get; set; }

        public string City { get; set; }


    }
}
