﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating object of customer

            Customer customer = new Customer();



      

        }

        
    }

    
}
