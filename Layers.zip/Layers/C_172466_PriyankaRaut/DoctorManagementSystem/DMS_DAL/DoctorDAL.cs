﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_Entities;
using DMS_Exception;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace DMS_DAL
{
    public class DoctorDAL
    {

        //Creating list to store the Doctor information

        static List<Doctor> Dlist = new List<Doctor>();

        //creting method to search the salesman in list
        public Doctor SearchDoctorDAL(string search_registration_no )

        {

            Doctor search_doc = null;

            try

            {
                //checking condition
                for (int i = 0; i < Dlist.Count; i++)

                {

                    Doctor doctor = Dlist[i];

                    if (doctor.Registration_no == search_registration_no)
                    {
                        search_doc = Dlist[i];
                        break;
                    }
                }
            }

            catch (Exception ex)

            {

                throw new DoctorException(ex.Message);

            }

            return search_doc;
        }
        // Code for Serializing doctor data
        public bool SerializeDataDAL(Doctor newdoctor)
        {
            bool DoctorSerialized = false;
            try
            {
                Dlist.Add(newdoctor);


                DoctorSerialized = true;
               //creating filestream to create file and store the salesman details

               FileStream fs = new FileStream("DoctorInfo.txt", FileMode.Create, FileAccess.Write);

                //creating binaryFormatter to serialized the data

                BinaryFormatter Formatter = new BinaryFormatter();

               //calling serialize method to store the object data in binaryformat

                Formatter.Serialize(fs,Dlist);
              //close the file stream close
                fs.Close();
            }

        catch (Exception ex)
      {

            throw new DMS_Exception.DoctorException(ex.Message);
           }
        return DoctorSerialized;

    }
        // Code for deserialize data

        public List<Doctor> DeserializeDataDAL()
       {
            //Creating instance for filestream to open the file
            //    

            FileStream fs = new FileStream("DoctorInfo.txt", FileMode.Open, FileAccess.Read);
         
            //creating binaryFormatter instance to deserialized the data
           BinaryFormatter formatter = new BinaryFormatter();
          
            //storing the deserialize data in list
         List<Doctor> DoctorList = formatter.Deserialize(fs) as List<Doctor>;
           
            //close the filestream
           fs.Close();

           return DoctorList;
        }
    }
}
