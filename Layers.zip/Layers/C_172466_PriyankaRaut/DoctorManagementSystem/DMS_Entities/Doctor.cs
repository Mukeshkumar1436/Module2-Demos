﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS_Entities
{
    [Serializable]
    public class Doctor
    {
        //Creating properties for doctor 

        public string Registration_no { get; set; }

        public string DoctorName { get; set; }

        public string City { get; set; }

        public string Specialization { get; set; }

        public string Address { get; set; }

        public string Contact_no { get; set; }

    }
}
