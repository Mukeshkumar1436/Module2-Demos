﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_Entities;
using DMS_DAL;
using DMS_Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;//adding namespaces 

namespace DMS_BAL
{



    //Creating Doctor Business Access Layer
    //Here we are validating the data for Properties provided in entity layer.
    //It also acts as Wrapper for CRUD operationds in DAL layer.

    public class DoctorBAL
    {


        //Validating Doctor Data
        private static bool ValidateDoctor(Doctor doctor)
        {
            //Creating string builder instance

            StringBuilder sb = new StringBuilder();

                bool validdoctor = true;

           /*if(doctor.Registration_no=string.Empty)
            {

                validdoctor = false;
                sb.Append(Environment.NewLine + "Salesman Code cannot be empty");
            }*/


            if (doctor.Registration_no.Length != 7)

            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "Excatly required 7 Digit registration no. only");

            }


            if (doctor.DoctorName == string.Empty)
            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "Doctor Name Required");
            }

            if (doctor.Specialization == string.Empty)
            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "Area of Specilization Required");
            }


            if (doctor.Address == string.Empty)
            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "Address  Required");
            }


            if (doctor.Contact_no.Length <= 9 || doctor.Contact_no.Length >= 11)
            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }


            if (doctor.City.Equals("Pune") || doctor.City.Equals("Mumbai") || doctor.City.Equals("Bangalore") || doctor.City.Equals("Hyderabad"))

            {
            }

            else
            {
                validdoctor = false;
                sb.Append(Environment.NewLine + "City Has to be Pune, Mumbai , Bangalore and Hyderabad");
            }

            if (validdoctor == false)
            {

                throw new DMS_Exception.DoctorException(sb.ToString());
            }
            return validdoctor;

        }


        public static Doctor SearchDoctorBL(string search_registration_no)

        {
            Doctor search_doc = null;

            try
            {
                DMS_DAL.DoctorDAL doctorDAL = new DMS_DAL.DoctorDAL ();
                search_doc = doctorDAL.SearchDoctorDAL(search_registration_no);
            }
            catch (DMS_Exception.DoctorException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;

            }
            return search_doc;

        }


        //Serialization of the data

        public static bool SerializeDataBL(Doctor doctor)

        {
            bool DoctorSerialized = false;

            try
            {

                if (ValidateDoctor(doctor))

                {
                    DMS_DAL.DoctorDAL doctorDAL = new DMS_DAL.DoctorDAL();

                    DoctorSerialized = doctorDAL.SerializeDataDAL(doctor);

                }

            }
            catch (DMS_Exception.DoctorException e)

            {

                throw e;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return DoctorSerialized;
        }


        public static List<Doctor> DeserializeDataBL()

        {

            List<Doctor> DoctorList = null;

            try

            {

                DMS_DAL.DoctorDAL doctorDAL = new DMS_DAL.DoctorDAL();

                DoctorList = doctorDAL.DeserializeDataDAL();
            }

            catch (DMS_Exception.DoctorException e)

            {

                throw e;
            }

            catch (Exception ex)
            {

                throw ex;

            }

            return DoctorList;

        }

    }
}
