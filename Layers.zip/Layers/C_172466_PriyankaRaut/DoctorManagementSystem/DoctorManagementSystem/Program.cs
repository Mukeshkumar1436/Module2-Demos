﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_BAL;
using DMS_DAL;
using DMS_Entities;
using DMS_Exception;

namespace DoctorManagementSystem
{
    //It is Presentation Layer and also called as User Interface.

    class Program
    {

        static void Main(string[] args)
        {
            PrintMenu();
        }
        private static void PrintMenu()

        {
            string Select;
            do

            {
           
                Console.WriteLine($"Doctor Management System ");

                Console.WriteLine($"1. Searching Doctor Information");

                Console.WriteLine("2. Serialize the data");

                Console.WriteLine("3. Deserialize the data");

                Console.WriteLine("Enter choice");

                int Choice = Convert.ToInt32(Console.ReadLine());
                switch (Choice)

                {

                    case 1:

                        SearchDoctorreg();

                        break;

                    case 2:

                        SerializeData();

                        break;

                    case 3:

                       // DeserializeData();

                        break;

                    default:

                        Console.WriteLine("invalid choice:select 1-3");

                        break;

                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                Select = Console.ReadLine();

            } while ((Select == "y"));

            Console.Read();
        }
        private static void SearchDoctorreg()
        {
            try
            {
                string search_registration_no;

                Console.WriteLine("Enter registration no. to Search doctor information:");

                search_registration_no = Console.ReadLine();

                Doctor search_doc = DMS_BAL.DoctorBAL.SearchDoctorBL(search_registration_no);
                if (search_doc != null)

                {
                    Console.WriteLine("-------****---------");
                    Console.WriteLine($"Registration_no ,Doctor Name, City , Area of Specialization ,Address, Contact no.");

                    Console.WriteLine("-------****---------");

                    Console.WriteLine("{0},{1},{2},{3},{4}", search_doc.Registration_no, search_doc.DoctorName, search_doc.City, search_doc.Specialization, search_doc.Address,search_doc.Contact_no);

                    Console.WriteLine("-------****---------");

                }

                else

                {

                    Console.WriteLine(" Doctors Details Not Available");

                }

            }

            catch (DMS_Exception.DoctorException ex)

            {

                Console.WriteLine(ex.Message);
            }
        }

        //Perform serialization on the data

        private static void SerializeData()

        {
            try

            {

                Doctor Newdoctor = new Doctor();

                Console.WriteLine("Enter Registration number :");

                Newdoctor.Registration_no = Console.ReadLine();

                Console.WriteLine("Enter Doctor Name :");

                Newdoctor.DoctorName = Console.ReadLine();

                Console.WriteLine("Enter City (Pune,Mumbai,hyderabad,bangalore) :");

                Newdoctor.City = Console.ReadLine();

                Console.WriteLine("Enter Area of specialization :");

                Newdoctor.Specialization = (Console.ReadLine());

                Console.WriteLine("Enter Address :");

                Newdoctor.Address = (Console.ReadLine());

                Console.WriteLine("Enter Contact number :");

                Newdoctor.Contact_no = (Console.ReadLine());

                bool DoctorSerialized = DMS_BAL.DoctorBAL.SerializeDataBL(Newdoctor);

                if (DoctorSerialized)

                    Console.WriteLine("Doctor data is Serialized");

                else

                    Console.WriteLine("Doctordata is  not Serialized");

            }

            catch (DMS_Exception.DoctorException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }

        //Perform Deserialization on the data

        private static void DeserializeData()

        {

            try

            {

                List<Doctor> DoctorList = DMS_BAL.DoctorBAL.DeserializeDataBL();

                if (DoctorList != null && DoctorList.Count > 0)

                {

                    Console.WriteLine("-------****---------");
                    Console.WriteLine("Registration no. ,Doctor Name , City");

                    Console.WriteLine("-------****---------");

                    foreach (Doctor doctor in DoctorList)

                    {

                        Console.WriteLine($"{0},{1},{2},{3},{4}", doctor.Registration_no, doctor.DoctorName, doctor.City, doctor.Address, doctor.Specialization,doctor.Contact_no);

                    }
                    Console.WriteLine("-------****---------");

                }

                else

                {

                    Console.WriteLine(" Serialized Data Not Available");

                }

            }

            catch (DMS_Exception.DoctorException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }


    }
}
