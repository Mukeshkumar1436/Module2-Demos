﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172415
 * Author Name: Ambedkar
 * Creation Date:05/03/2019
*/
namespace SMS_Entities
{
    [Serializable]
    public class Student
    {
        //Creating the property fields for the following
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string CourseName { get; set; }
        // public DateTime EntryDate { get; set; }
        public char Grade { get; set; }
    }
}
