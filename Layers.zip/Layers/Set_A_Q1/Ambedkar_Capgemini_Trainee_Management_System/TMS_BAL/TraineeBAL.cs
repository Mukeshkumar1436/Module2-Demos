﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMS_Entities;
using TMS_Exceptions;
using TMS_DAL;

namespace TMS_BAL
{
    public class TraineeBAL
    {
        //using generic concept
        public static List<Trainee> tainees = new List<Trainee>();
        // private static object studs;
        private static bool ValidateTrainee(Trainee trainee)
        {
            StringBuilder sb = new StringBuilder();
            bool validTrainee = true;
            //validating whether the data is empty or not
            if (trainee.TraineeId <= 6)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Invalid Trainee RollNo");

            }
            if (trainee.ModuleName == string.Empty)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Module Name Required");

            }
            if (trainee.BatchName == string.Empty)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Batch Name Required or Invalid Batch Name");
            }
            
           
            if (validTrainee == false)
                throw new TraineeNotFoundException(sb.ToString());
            return validTrainee;
        }
        //Adding student information
        public static bool AddTraineeBAL(Trainee newTrainee)
        {
            bool TraineeAdded = false;
            try
            {
                if (ValidateTrainee(newTrainee))
                {
                    TraineeDAL traineeDAL = new TraineeDAL();
                    TraineeAdded = traineeDAL.AddTraineeDAL(newTrainee);
                }
            }
            catch (TraineeNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return TraineeAdded;
        }
        //displaying student
        public static Trainee DisplayParticularTraineeBAL(string displayTraineeName)
        {
            Trainee displayTrainee = null;
            try
            {
                TraineeDAL traineeDAL = new TraineeDAL();
                displayTrainee = traineeDAL.DisplayParticularTraineeDAL(displayTraineeName);
            }
            catch (TraineeNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return displayTrainee;

        }
        public static void SerializeData()
        {
            TraineeDAL.SerializeData();
        }

        public static void DeserializeData()
        {
            TraineeDAL.DeserializeData();
        }
    };
}
