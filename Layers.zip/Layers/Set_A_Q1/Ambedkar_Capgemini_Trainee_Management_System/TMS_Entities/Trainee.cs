﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMS_Entities
{
    [Serializable]
    public class Trainee
    {
           //Creating the property fields for the following
        public int TraineeId { get; set; }
        public string ModuleName { get; set; }
        public string BatchName { get; set; }
        public DateTime EntryDate { get; set; }
        public string Comments { get; set; }
    }
}
