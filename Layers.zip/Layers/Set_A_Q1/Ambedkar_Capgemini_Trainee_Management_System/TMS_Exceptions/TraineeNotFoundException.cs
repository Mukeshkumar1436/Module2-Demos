﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMS_Exceptions
{
    [Serializable]
    public class TraineeNotFoundException : Exception
    {
       
            //creating the exceptions if the student information is not valid then exception is thrown
            public TraineeNotFoundException() { }
            public TraineeNotFoundException(string message) : base(message) { }
            public TraineeNotFoundException(string message, Exception inner) : base(message, inner) { }
          
    };

}
