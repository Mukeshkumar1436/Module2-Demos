﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMS_Entities;
using TMS_Exceptions;
using TMS_BAL;

namespace Ambedkar_Capgemini_Trainee_Management_System
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintMenu();   // Calling Function
        }
        public static void AddTrainee()
        {
            try
            {
                Trainee t = new Trainee();
                WriteLine("Enter the Trainee ID :");
                t.TraineeId = Convert.ToInt32(ReadLine());
                WriteLine("Enter the Module Name :");
                t.ModuleName = ReadLine();
                Console.WriteLine("Enter the Batch Name");
                t.BatchName = ReadLine();
                WriteLine("Enter the Date of Joining in Format of MM/DD/YYYY : ");
                t.EntryDate = DateTime.Parse(ReadLine());
                WriteLine("Enter Trainee Comments : ");
                t.Comments = ReadLine();

                bool traineeAdded = TraineeBAL.AddTraineeBAL(t);
                if (traineeAdded == true)
                {
                    WriteLine("Trainee added successfully...");
                }
                else
                {
                    throw new TraineeNotFoundException("Trainee not added....");

                }
                TraineeBAL.SerializeData();
            }
            catch (TraineeNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void DisplayParticularTrainee()
        {
            string Name;
            Trainee displaytrainee;
            try
            {
                WriteLine("Enter Module Name to be Displayed : ");
                Name = ReadLine();

                displaytrainee = TraineeBAL.DisplayParticularTraineeBAL(Name);
                if (displaytrainee != null)
                {
                    WriteLine("Trainee RollNo : " + displaytrainee.TraineeId);
                    WriteLine("Module Name : " + displaytrainee.ModuleName);
                    WriteLine("Trainee Batch Name : " + displaytrainee.BatchName);
                    WriteLine("Trainee Date of Joining : " + displaytrainee.EntryDate);
                    WriteLine("Trainee Comments : " + displaytrainee.Comments);
                }
                else
                {
                    throw new TraineeNotFoundException("Trainee Not Found .....");
                }
            }
            catch (Exception e2)
            {
                WriteLine(e2.Message);
            }
        }
        public static void PrintMenu()
        {
            try
            {


                string Choice1;    //dsiplaying menu
                do
                {
                    WriteLine("\n============Trainee Management System ================");
                    WriteLine("1. Add The Trainee Information : ");
                    WriteLine("2. Display Performance Details of Particular Trainee : ");
                    WriteLine("3.Serialize Data");
                    WriteLine("4.Deserialize Data");
                    WriteLine("Enter your Choice...");
                    int choice = Int32.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddTrainee(); break;
                        case 2: DisplayParticularTrainee(); break;
                        case 3: TraineeBAL.SerializeData(); WriteLine("Data Serialized...."); break;
                        case 4: TraineeBAL.DeserializeData(); WriteLine("Data Deserialized..."); break;

                        default: WriteLine("Invalid Choice...."); break;

                    }
                    WriteLine("Do you want to contiue(Y/N)?");
                    Choice1 = ReadLine();
                } while (Choice1 == "Y" || Choice1 == "y");
            }
            catch(Exception ex)
            {
                WriteLine("Exception : " + ex.Message);
            }
            finally
            {
                WriteLine("Execution Completed....\nRun Again.....");
            }
            ReadKey();

        }
    };
}
