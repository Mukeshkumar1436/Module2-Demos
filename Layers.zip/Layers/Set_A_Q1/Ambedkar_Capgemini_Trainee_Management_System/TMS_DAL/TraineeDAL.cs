﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using TMS_Entities;
using TMS_Exceptions;

namespace TMS_DAL
{
    public class TraineeDAL
    {
        public static List<Trainee> trainees = new List<Trainee>();
        public bool AddTraineeDAL(Trainee trainee)
        {
            bool traineeAdded = false;
            try
            {
                trainees.Add(trainee);
                traineeAdded = true;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return traineeAdded;
        }
        //--------------------------------------------
        public Trainee DisplayParticularTraineeDAL(string name)
        {
            try
            {
                Trainee displayedTrainee = null;
                foreach (var trainee in trainees)
                {
                    if (trainee.ModuleName == name)
                    {
                        displayedTrainee = trainee;
                    }

                }
                return displayedTrainee;
            }

            catch (Exception ex2)
            {
                throw ex2;
            }

        }
        //---------------------------------------
        
        public static void SerializeData()
        {
          
            try
            {
                FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, trainees);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        //deserializing data
        public static List<Trainee> DeserializeData()
        {
            FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            trainees = formatter.Deserialize(stream) as List<Trainee>;
            return trainees;

        }
    };
}
