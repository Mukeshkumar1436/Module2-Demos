﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Reliance_Energy_Entities;
using Reliance_Energy_Exceptions;
using Reliance_Energy_Bill_BAL;


namespace Ambedkar_RelianceEnergy
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintMenu();
        }
        private static void PrintMenu() //Print Menu
        {
            string choice1;
            do
            {
                Console.WriteLine("\n***********Electricity Bill ***********");
                Console.WriteLine("1. Add Electricity Bill");
                Console.WriteLine("2. Delete Electricity Bill");
                Console.WriteLine("3. Get all Electricity Details");
                Console.WriteLine("4. Search For Customer Details");
                Console.WriteLine("5. UpdateElectricity");
                Console.WriteLine("Enter Your Choice :");
                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddElectricityBill();
                        break;
                    case 2:
                        DeleteElectricityBill();
                        break;
                    case 3:
                        ListAllElectricityBill();
                        break;
                    case 4:
                        SearchByCustomerID();
                        break;
                    case 5:
                        UpdateElectricityBill();
                        break;
                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y" || choice1=="Y"));
            //Console.Read();
        }
        private static void AddElectricityBill() //Add Electricity Bill Details
        {
            try
            {
                Electricity newElectricity = new Electricity();
                Console.WriteLine("Enter Bill Number");
                newElectricity.BillNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Customer ID :");
                newElectricity.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Customer Name :");
                newElectricity.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newElectricity.Phone = Console.ReadLine();
                Console.WriteLine("Enter Customer Address :");
                newElectricity.Address = Console.ReadLine();
                Console.WriteLine("Enter Email Address :");
                newElectricity.EmailID = Console.ReadLine();
                Console.WriteLine("Enter Consumed Units :");
                newElectricity.UnitConsumed = int.Parse(Console.ReadLine());
                bool ElectricityAdded = ElectricityBLL.AddElectricityBL(newElectricity);
                if (ElectricityAdded)
                    Console.WriteLine("Electricity Added");
                else
                    Console.WriteLine("Electricity not Added");
            }
            catch (REException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ListAllElectricityBill() //List all the Electricity Bills
        {
            int surcharge = 5;
            int rate = 6;
            try
            {
                List<Electricity> ElectricityList = ElectricityBLL.GetAllElectricitysBL();
                if (ElectricityList != null && ElectricityList.Count > 0)
                {
                    Console.WriteLine("****************************************************************************************************************");
                    Console.WriteLine("CustomerID\tName\tPhoneNumber\t\tEmail\t\tAddress\t Consumed Units\t\tAmount \t Gross Amount");
                    Console.WriteLine("*******************************************************************************************************************");
                    foreach (Electricity Electricity in ElectricityList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t\t{7}", Electricity.CustomerID, Electricity.CustomerName, Electricity.Phone, Electricity.EmailID,Electricity.Address, Electricity.UnitConsumed, Electricity.UnitConsumed * rate, (Electricity.UnitConsumed * rate)+((Electricity.UnitConsumed * rate) * surcharge)/100 );
                    }
                    Console.WriteLine("******************************************************************************************************");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("No Electricity Details Available");
                }
            }
            catch (REException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void UpdateElectricityBill() // Update all Electricity Bills
        {
            try
            {
                int updateElectricityID;
                Console.WriteLine("Enter ElectricityID to Update Details:");
                updateElectricityID = Convert.ToInt32(Console.ReadLine());
                Electricity updatedElectricity = ElectricityBLL.SearchElectricityBL(updateElectricityID);
                if (updatedElectricity != null)
                {
                    Console.WriteLine("Update Electricity Name :");
                    updatedElectricity.CustomerName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedElectricity.Phone = Console.ReadLine();
                    bool ElectricityUpdated = ElectricityBLL.UpdateElectricityBL(updatedElectricity);
                    if (ElectricityUpdated)
                        Console.WriteLine("Electricity Details Updated");
                    else
                        Console.WriteLine("Electricity Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Electricity Details Available");
                }
            }
            catch (REException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchByCustomerID() // Search Electricity Details by Customer ID
        {
            try
            {
                int searchElectricityID;
                Console.WriteLine("Enter CustomerID to Search:");
                searchElectricityID = Convert.ToInt32(Console.ReadLine());
                Electricity searchElectricity = ElectricityBLL.SearchElectricityBL(searchElectricityID);
                if (searchElectricity != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("ElectricityID\t\tName\t\tPhoneNumber\t\tAddress\t\tEmailID");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t{3}\t{4}", searchElectricity.CustomerID, searchElectricity.CustomerName, searchElectricity.Phone, searchElectricity.Address, searchElectricity.EmailID);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Electricity Details Available");
                    Console.ReadLine();
                }
            }
            catch (REException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeleteElectricityBill() //Delete the Bill Details of Particular Customer ID.
        {
            try
            {
                int deleteElectricityID;
                Console.WriteLine("Enter ElectricityID to Delete:");
                deleteElectricityID = Convert.ToInt32(Console.ReadLine());
                bool Electricitydeleted = ElectricityBLL.DeleteElectricityBL(deleteElectricityID);
                if (Electricitydeleted)
                    Console.WriteLine("Electricity Deleted");
                else
                    Console.WriteLine("Electricity not Deleted ");
            }
            catch (REException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    };
}
