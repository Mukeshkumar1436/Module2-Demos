﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reliance_Energy_Entities
{
    public class Electricity
    {
        public int BillNo { get; set; }

        public int CustomerID { get; set; } 

        public string CustomerName { get; set; }

        public string Phone { get; set; }

        public string Address { get; set; }

        public string EmailID { get; set; }

        public int UnitConsumed { get; set; }

        public string Rate { get; set; }

        public int Amount { get; set; }

        public int Surcharge { get; set; }

        public string GrossAmount { get; set; }

    };
}
