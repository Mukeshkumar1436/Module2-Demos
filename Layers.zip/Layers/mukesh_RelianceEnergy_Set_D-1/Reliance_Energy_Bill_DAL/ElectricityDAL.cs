﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Reliance_Energy_Entities;
using Reliance_Energy_Exceptions;


namespace Reliance_Energy_Bill_DAL
{
    public class ElectricityDAL
    {
        static List<Electricity> electricityList = new List<Electricity>();
        public bool AddElectricityDAL(Electricity newElectricity)
        {
            bool electricityAdded = false;
            try
            {
                electricityList.Add(newElectricity);
                electricityAdded = true;
            }
            catch (Exception ex)
            {
                throw new REException(ex.Message);
            }
            return electricityAdded;
        }
        public List<Electricity> GetAllElectricitysDAL()
        {
            return electricityList;
        }
        public bool DeleteElectricityDAL(int deleteelectricityID)
        {
            bool electricityDeleted = false;
            try
            {
                for (int i = 0; i < electricityList.Count; i++)
                {
                    Electricity electricity = electricityList[i];
                    if (electricity.CustomerID == deleteelectricityID)
                    {
                        electricityList.RemoveAt(i);
                        electricityDeleted = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new REException(ex.Message);
            }
            return electricityDeleted;
        }
        public Electricity SearchElectricityDAL(int searchElectricityID)
        {
            Electricity searchelectricity = null;
            try
            {
                for (int i = 0; i < electricityList.Count; i++)
                {
                    Electricity electricity = electricityList[i];
                    if (electricity.CustomerID == searchElectricityID)
                    {
                        searchelectricity = electricityList[i];
                        break;
                    }
                }
            }
            //  Catching Exceptions
            catch (Exception ex)
            {
                throw new REException(ex.Message);
            }
            return searchelectricity;
        }
        public bool UpdateElectricityDAL(Electricity updateElectricity)
        {
            bool electricityUpdated = false;
            try
            {
                for (int i = 0; i < electricityList.Count; i++)
                {
                    Electricity electricity = electricityList[i];
                    if (electricity.CustomerID == updateElectricity.CustomerID)
                    {
                        electricityList[i] = updateElectricity;
                        break;
                    }
                }
                electricityUpdated = true;
            }
            catch (Exception ex)
            {
                throw new REException(ex.Message);
            }
            return electricityUpdated;
        }
    };
}
