﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Ambedkar_Exceptions_Layers

namespace EMS_Exception
{
    public class ProductValidationException : Exception
    {
        public ProductValidationException(string message) : base(message)
        {

        }
    }
}
