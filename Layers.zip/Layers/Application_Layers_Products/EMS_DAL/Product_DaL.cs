﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exception;

namespace EMS_DAL
{
    public class Product_DaL
    {
        List<Product_Entities> products = new List<Product_Entities>();
        public List<Product_Entities> SelectAll()
        {
            return products;
        }
        //---------------------------------------
        public void Insert(Product_Entities product)
        {
            try
            {
                products.Add(product);

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void Update(Product_Entities product)
        {
            try
            {
                // 1. Using LINQ Query Expression
                //var prd = (from p in products
                //          where p.ProductID == product.ProductID
                //          select p).SingleOrDefault();
                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                // 2. Extension method & Lambda
                var prd2 = products.SingleOrDefault(p => p.ProductID == product.ProductID);
                if (prd2 != null)
                {
                    prd2.Name = product.Name;
                    prd2.Price = product.Price;
                    prd2.ExpDate = product.ExpDate;
                }
                else
                {
                    throw new ProductNotFoundException("Product Not Found");
                }

                // Normal Join
                //for (int i = 0; i < products.Count; i++)
                //{
                //    if (products[i].ProductID == product.ProductID)
                //    {
                //        products[i].Name = product.Name;
                //        products[i].Price = product.Price;
                //        products[i].ExpDate = product.ExpDate;
                //        break;
                //    }
                //}
                //products.Add(product);

            }
            catch (ProductNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // ---------  Delete   -------------------------
        public void Delete(int id)
        {
            bool isDeleted = false;
            try
            {
                for (int i = 0; i < products.Count; i++)
                {
                    if (products[i].ProductID == id)
                    {
                        // employees.Remove(employees[i]);
                        products.RemoveAt(i);
                        isDeleted = true;
                        break;
                    }
                }
                if (!isDeleted)
                {
                    throw new ProductNotFoundException("Not Found!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        //public void Delete(Product_Entities product)
        //{
        //    try
        //    {
        //        // 1. Using LINQ Query Expression
        //        //var prd = (from p in products
        //        //           where p.ProductID == product.ProductID
        //        //           select p).SingleOrDefault();
        //        //prd.Name = product.Name;
        //        //prd.Price = product.Price;
        //        //prd.ExpDate = product.ExpDate;

        //        // 2. Extension method & Lambda
        //        var prd2 = products.SingleOrDefault(p => p.ProductID == product.ProductID);
        //        if(prd2!= null)
        //        {
        //           // products.RemoveAt(p);
        //            products.Remove(prd2);
        //        }
        //        //prd2.Name = product.Name;
        //        //prd2.Price = product.Price;
        //        //prd2.ExpDate = product.ExpDate;

        //       else
        //       {
        //            throw new ProductNotFoundException("Product Not Found");
        //        }
        //        //products.Add(product);

        //    }
        //    catch (ProductNotFoundException ex)
        //    {
        //        throw ex;
        //    }
        //    catch(Exception ex2)
        //    {
        //        throw ex2;
        //    }
        //}
        // ---------------------------------------
        public Product_Entities Search(int id)
        {
            var prd = products.SingleOrDefault(p => p.ProductID == id);
            return prd;
        }
        public  void SerializeData()
        {
            
            try
            {
                FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a2.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, products);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        //deserializing data
        public List<Product_Entities> DeserializeData()
        {
            FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a2.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            products = formatter.Deserialize(stream) as List<Product_Entities>;
            return products;

        }
    }
}
