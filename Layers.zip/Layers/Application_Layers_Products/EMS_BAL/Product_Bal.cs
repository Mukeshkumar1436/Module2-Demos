﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exception;
using EMS_DAL;
using System.Text.RegularExpressions;

namespace EMS_BAL
{
    public class Product_Bal
    {
        Product_DaL dal = new Product_DaL();
        public bool IsValid(Product_Entities product)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (product.Name == string.Empty)
            {
                sb.Append("Name is Required," + Environment.NewLine);
                valid = false;
            }

            if (!Regex.IsMatch(product.Name, @"^[\p{L} \.\-]+$"))
            {
                sb.Append("Name should not contain Digits," + Environment.NewLine);
                valid = false;
            }
            if (!Regex.IsMatch(product.Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
            {
                sb.Append("Enter Valid Email Address, " + Environment.NewLine);
                valid = false;
            }
            if(product.Price < 0 )
            {
                sb.Append("Price is > 0, " + Environment.NewLine);
                valid = false;
            }
            if (product.ExpDate < DateTime.Now)
            {
                sb.Append("Enter Valid Expected Date," + Environment.NewLine);
                valid = false;
            }
            //if (product.ExpDate > DateTime.Now)
            //{
            //    sb.Append("Expected Date is always past Date");
            //    valid = false;
            //}

            if (!valid)
            {
                throw new ProductValidationException(sb.ToString());
            }
            
            return valid;
        }

        public Product_Entities Find(int id)
        {
            return dal.Search(id);
        }

        public List<Product_Entities> GetAll()
        {
            return dal.SelectAll();
        }
        // Add into List
        public void Add(Product_Entities product)
        {
            try
            {
                if(IsValid(product))
                {
                    dal.Insert(product);
                }
                else
                {
                    Console.WriteLine("Data Not Inserted...");
                }

            }
            catch(ProductValidationException ex)
            {
                throw ex;
            }
            catch(Exception)
            {
                throw;
            }
        }
        //  
        public void Edit(Product_Entities product)
        {
            try
            {
                if (IsValid(product))
                {

                    dal.Update(product);
                }
                else
                {
                    Console.WriteLine("Data Not Updated...");
                }
            }
            catch (ProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }
        // Remove
        public void Remove(int id)
        {
            try
            {

                dal.Delete(id);
                    
                
            }
            catch (ProductNotFoundException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }
        //-----------------------
        public void SerializeData()
        {
            dal.SerializeData();
            // dal.SerializeData();
        }
        public  void DeserializeData()
        {
            dal.DeserializeData();
        }
    }
}
