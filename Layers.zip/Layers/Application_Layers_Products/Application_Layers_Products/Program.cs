﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exception;
using EMS_BAL;

namespace Application_Layers_Products
{
    class Program
    {
        static void Main(string[] args)
        {
       
            try
            {
          
                Product_Bal bal = new Product_Bal();
                string ch;
                do
                {
                    int choice = PrintMenu();
                    Product_Entities product = null;
                    int id;
                    //int Count = 100;
                    // Product_Entities prod = null;
                    // string ch;   //= char.Parse(ReadLine());
                    switch (choice)
                    {
                        case 1:/*Program p = new Program();p.aaa();*/
                              product = CreateProduct();
                            bal.Add(product);
                            Console.WriteLine("Inserted ");
                            break;
                        case 2:
                            product = CreateProduct();
                            Console.WriteLine("Enter Product ID");
                            product.ProductID = int.Parse(ReadLine());
                           
                            bal.Edit(product);
                            break;
                        case 3:
                            Console.WriteLine("Enter id of product to be deleted: ");
                            id = int.Parse(Console.ReadLine());
                            bal.Remove(id);
                            break;
                        case 4:
                            List<Product_Entities> prods = bal.GetAll();
                            DisplayProducts(prods);
                            break;
                        case 5:
                            Console.WriteLine("Enter id of product to be searched: ");
                            id = int.Parse(Console.ReadLine());
                            product = bal.Find(id);
                            Console.WriteLine(product);
                            break;
                        case 6: bal.SerializeData();
                            Console.WriteLine("Data is Serialized...");
                            break;
                        case 7:bal.DeserializeData();
                            Console.WriteLine("Data is De-Serialized..."); break;
                        case 8: Console.WriteLine("---Thank you----\n---Program Terminated--- "); break;

                        default: Console.WriteLine("Enter vaild choice"); break;
                    }
                    WriteLine("Do you want to Continue Y/N or y/n....");
                    ch = ReadLine();
                } while (ch == "Y" || ch == "y");
            }
            catch (ProductNotFoundException ex2)
            {
                WriteLine(ex2.Message);
            }
            catch (ProductValidationException ex1)
            {
                WriteLine(ex1.Message);
            }
            catch (Exception ex)
            {
                WriteLine("Exception :"+ex.Message);
            }
            finally
            {
                WriteLine("Execution Completed.... \n....Run Again....");
            }
            
            ReadKey();

        }
        static int PrintMenu()
        {
            WriteLine("------------Menu-----------\n1.Add\n2.Update\n3.Delete\n4.Display\n5.Search\n6.Serialization \n7.Deserialization\n8.Exit\n");
            WriteLine("Select Your Choice ");
            int choice = int.Parse(ReadLine());
            return choice;
        }
        // ----    Create Products  -----
        static Product_Entities CreateProduct()
        {
            Product_Entities product = new Product_Entities();
            Console.WriteLine("Enter product details:");
            Console.Write("Name: ");
            product.Name = Console.ReadLine();
            Console.Write("Price: ");
            product.Price = int.Parse(Console.ReadLine());
            Console.Write("Expiry Date: (MM/DD/YYYY) : ");
            product.ExpDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Email: ");
            product.Email = Console.ReadLine();

            return product;

        }
        // ---   Display  ------

        static void DisplayProducts(List<Product_Entities> prods)
        {

                foreach (var prd in prods)
                {
                    Console.WriteLine(prd);
                }

        }
        //public void aaa()
        //{
        //    Product_Entities product = new Product_Entities();
        //    product.Product_Entities_();
        //}
        //------  End  --

    }
}
