﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Entities
{
    [Serializable]
    public class Product_Entities
    {

        static int Count = 100;

        public Product_Entities()
        {
            Count++;
            ProductID = Count;
        }
        //public void Product_Entities_()
        //{
        //    Count++;
        //    ProductID = Count;
        //}

        public int ProductID { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public DateTime ExpDate { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return $"Id :{ProductID} {Environment.NewLine} Name : {Name}{Environment.NewLine} Price:{Price} {Environment.NewLine} Email : {Email} {Environment.NewLine} ExpDate : {ExpDate}{Environment.NewLine}";
        }
    }
}
