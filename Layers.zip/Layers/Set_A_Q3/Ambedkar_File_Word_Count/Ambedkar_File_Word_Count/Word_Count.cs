﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ambedkar_File_Word_Count
{
    class Word_Count
    {
        static void Main(string[] args)
        {
                                        // Text File  
            string inFileName = @"C:\Users\amgogu\Desktop\Module-2\Set_A_Q3\Ambedkar_Text_File.txt";
                                        // Reading Data from Text File
            StreamReader sr = new StreamReader(inFileName);
                                        // Variable Declaration
            int Counter = 0;
            string Delim = " ,.";
            string[] Fields = null;
            string Line = null;

            while (!sr.EndOfStream)
            {
                Line = sr.ReadLine();  // Reading Data
            }
            Fields = Line.Split(Delim.ToCharArray());
            for (int i = 0; i < Fields.Length; i++)
            {
                Counter++;
            }
            sr.Close();                // Closing Stream Reader....
            WriteLine($"The Number of Words in Text File is : {Counter}");
            ReadKey();
        }
    };
}
