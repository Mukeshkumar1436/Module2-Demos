﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketEntities
{
    [Serializable]
    // --- Entities---
    public class Passenger
    {
        public string PNRNo { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime DOJ { get; set; }
        public DateTime BookingDate { get; set; }
        public string Type { get; set; }
        public string NoofTickets { get; set; }

    }
}
