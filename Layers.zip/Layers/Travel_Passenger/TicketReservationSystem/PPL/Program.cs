﻿using PassengerBAL;
using PassengerException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketEntities;

namespace PPL
{
    class Program
    {
        public static void AddPassenger()
        {
            try
            {
                Passenger p = new Passenger();
                Console.Write("Enter the Passenger PNR-No : ");
                p.PNRNo = Console.ReadLine();
                Console.Write("Enter the Source Location : ");
                p.Source = Console.ReadLine();
                Console.Write("Enter the Destination Location : ");
                p.Destination =Console.ReadLine();
                Console.Write("Enter the Date of Journey : ");
                p.DOJ =DateTime.Parse( Console.ReadLine());
                Console.Write("Enter the Booking Date : ");
                p.BookingDate = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter the Type of Class (3AC, 2AC, SLEEPER ) : ");
                p.Type = Console.ReadLine();
                Console.Write("Enter the No Of Tickets : ");
                p.NoofTickets = Console.ReadLine();

                bool passengerAdded = PBAL.AddPassengerBAL(p);
                if (passengerAdded == true)
                {
                    Console.WriteLine("Passenger added successfully");
                }
                else
                {
                    throw new PException("Passenger not added successfully");

                }
               
            }
            catch (PException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        //--- Search Passenger
        public static void SearchPassenger()
        {

            string pnrno;
            Passenger searchpassenger;
            try
            {
                Console.Write("Enter PNR NO to Search : ");
                pnrno = Console.ReadLine();

                searchpassenger = PBAL.SearchPassengerBAL(pnrno);
                if (searchpassenger != null)
                {
                    Console.WriteLine("---  Passenger Detailes  ---");
                    Console.WriteLine("PNRNo : " + searchpassenger.PNRNo);
                    Console.WriteLine("Source : " + searchpassenger.Source);
                    Console.WriteLine("Date of journey : " + searchpassenger.DOJ);
                    Console.WriteLine("Destination : " + searchpassenger.Destination);
                    Console.WriteLine("BookingDate : " + searchpassenger.BookingDate);
                    Console.WriteLine("No Of Tickets : " + searchpassenger.NoofTickets);
                    Console.WriteLine("Type Of Journey : " + searchpassenger.Type);
                }
                else
                {
                    throw new PException("Passenger not found");
                }
            }
            catch (Exception e2)
            {
                Console.WriteLine(e2.Message);
            }
        }
        // -----  Menu
        public static void PrintMenu()
        {
            Console.WriteLine("********Passenger Menu********");
            Console.Write("1.Add Passenger\n");
            Console.Write("2.Search Passenger\n3.Serializtion \n4.Deserialization\n");
        }
        // ---- Main method
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                bool validChoice;
                Console.WriteLine("Enter your Choice : ");
                
                validChoice = Int32.TryParse(Console.ReadLine(), out choice);
                if (!validChoice)
                    Console.WriteLine("Enter the Only Numbers : ");
                else
                {
                    switch (choice)
                    {
                        case 1:
                            AddPassenger();
                            break;
                        case 2:
                            SearchPassenger();
                            break;
                        case 3:
                            PBAL.SerializeData();
                            Console.WriteLine("Data Serialized");break;
                        case 4:
                            PBAL.DeSerializeData();
                            Console.WriteLine("Data Deserialized"); break;
                        default:
                            Console.WriteLine("Invalid Choice ... Enter Only above Choice ...");
                            break;

                    }
                }
            }
            while (choice != 0);
            Console.ReadKey();
        }

    }
}
