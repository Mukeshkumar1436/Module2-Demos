﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassengerException
{

    [Serializable]
    //   ----  Exceptions
    public class PException : Exception
    {
        public PException() { }
        public PException(string message) : base(message) { }
        public PException(string message, Exception inner) : base(message, inner) { }
        //protected PException(
        //  System.Runtime.Serialization.SerializationInfo info,
        //  System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
