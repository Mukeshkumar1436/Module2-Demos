﻿using PassengerDAL;
using PassengerException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TicketEntities;

namespace PassengerBAL
{
    public class PBAL
    {
        //-------  Validation
        private static bool ValidatePassenger(Passenger passenger)
        {
            StringBuilder sb = new StringBuilder();
            bool validPassenger = true;
            if (!Regex.IsMatch(passenger.PNRNo, @"^[8][0-9]"))
            {
                sb.Append("PNR No Must be Starts with 8 ..."+Environment.NewLine);
                validPassenger = false;
            }
            if(passenger.PNRNo.Length!=8)
            {
                sb.Append("PNR No length must be 8 Digits..." + Environment.NewLine);
                validPassenger = false;
            }
            if(passenger.Source == string.Empty)
            {
                sb.Append("Source is Required..." + Environment.NewLine);
                validPassenger = false;
            }
            if (!Regex.IsMatch(passenger.Source, @"^[\p{L} \.\-]+$"))
            {
                sb.Append(" Source is Does not contain Digits..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.Destination == string.Empty)
            {
                sb.Append("Destination is Required..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.DOJ < DateTime.Now)
            {
                sb.Append("Date of Journey Must not be Past Date... Enter Future Date..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.DOJ < passenger.BookingDate)
            {
                sb.Append("Date of Journey Must be Greter than Bookking Date....Enter Coreect Date..." + Environment.NewLine);
                validPassenger = false;
            }
            if (!Regex.IsMatch(passenger.Destination, @"^[\p{L} \.\-]+$"))
            {
                sb.Append(" Destination is Does not contain Digits..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.Type == string.Empty)
            {
                sb.Append("Type is Required..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.Type != "SLEEPER" || passenger.Type != "3AC" || passenger.Type != "2AC" || passenger.Type != "1AC")
            {
                validPassenger = false;
                sb.Append("Passenger Type is invalid and Must be SLEEPER, 3AC, 2AC, 1AC" + Environment.NewLine);

            }
            if (passenger.NoofTickets == string.Empty)
            {
                sb.Append("Type is Required..." + Environment.NewLine);
                validPassenger = false;
            }
            if (!Regex.IsMatch(passenger.NoofTickets, @"^[0-9]"))
            {
                sb.Append("Enter only Digits..." + Environment.NewLine);
                validPassenger = false;
            }
            if (passenger.NoofTickets.Length > 8)
            {
                sb.Append("At a Time You cannot Book More than 8 Tickets..." + Environment.NewLine);
                validPassenger = false;
            }
            

            if (passenger.Source ==string.Empty)
            {
                validPassenger = false;
                sb.Append("Required Source" + Environment.NewLine);
            }
            if (passenger.Destination== string.Empty)
            {
                validPassenger = false;
                sb.Append("Required  Destination" + Environment.NewLine);
            }
            if (passenger.Type == string.Empty)
            {
                validPassenger = false;
                sb.Append("Required Type" + Environment.NewLine);
            }
           
            if (validPassenger == false)
                throw new PException(sb.ToString());
            return validPassenger;
        }
        //------   Add-Passenger 
        public static bool AddPassengerBAL(Passenger newpassenger)
        {
            bool PassengerAdded = false;
            try
            {
                if (ValidatePassenger(newpassenger))
                {
                    PDAL pDAL = new PDAL();
                    PassengerAdded = pDAL.AddPassengerDAL(newpassenger);
                }
                else
                {
                    Console.WriteLine("Passenger is Not Added...");
                }
            }
            catch (PException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PassengerAdded;
        }
        //-----   Search Passenger
        public static Passenger SearchPassengerBAL(string PNRNo)
        {
            Passenger searchPassenger = null;
            try
            {
                PDAL passengerDAL = new PDAL();
                searchPassenger = passengerDAL.SearchPassengerDAL(PNRNo);
            }
            catch (PException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPassenger;

        }
        //---- Serialization
        public static void SerializeData()
        {
            PDAL.SerializeData();
        }
        //  ---- De-Serialization
        public static void DeSerializeData()
        {
            PDAL.DeserializeData();
        }
    }
}
