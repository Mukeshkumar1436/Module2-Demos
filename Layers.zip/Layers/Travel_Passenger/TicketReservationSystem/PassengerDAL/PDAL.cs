﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using TicketEntities;

namespace PassengerDAL
{
    public class PDAL
    {
        public static List<Passenger> pass = new List<Passenger>();
        //----  Add-Passenger
        public bool AddPassengerDAL(Passenger passenger)
        {
            bool passengerAdded = false;
            try
            {
                pass.Add(passenger);
                passengerAdded = true;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return passengerAdded;
        }
        //------ Search Passenger
        public Passenger SearchPassengerDAL(string PnrNo)
        {
            try
            {
                Passenger searchedPassenger = null;
                foreach (var passenger in pass)
                {
                    if (passenger.PNRNo == PnrNo)
                    {
                        searchedPassenger = passenger;
                    }

                }
                return searchedPassenger;
            }

            catch (Exception ex2)
            {
                throw ex2;
            }

        }
        //------- Serialization
        public static void SerializeData()
        {

                FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a3.txt", FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, pass);
                stream.Close();
        }
        // ------ De-Serialization
        public static List<Passenger> DeserializeData()
        {
            FileStream stream = new FileStream(@"C:\Users\amgogu\Desktop\Ambedkar\a3.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            pass = formatter.Deserialize(stream) as List<Passenger>;
            return pass;

        }
    }
   

}
