﻿using System;
using System.Reflection;

namespace Ambedakr_Assembly
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter path");
            string asmPath = Console.ReadLine();
            Assembly path = Assembly.LoadFrom(asmPath);
            foreach(Type type in path.GetTypes())
            {
                Console.WriteLine(" Methods Type "+type.FullName);
                foreach(MethodInfo mi in type.GetMethods())
                {
                    Console.WriteLine(mi.ToString());
                }
                Console.WriteLine(" Fieds Information  "+type.FullName);
                foreach (FieldInfo fi in type.GetFields())
                {
                    Console.WriteLine(fi.ToString());
                }
                Console.WriteLine(" Properties Information  " + type.FullName);
                foreach (PropertyInfo pi in type.GetProperties())
                {
                    Console.WriteLine(pi.ToString());
                }
            }

            Console.ReadKey();

        }
    }
}
