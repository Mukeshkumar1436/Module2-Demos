﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_BAL;
using EMS_Entities;
using EMS_Exceptions;

// Presentation Layer

namespace Employee_MAnagement_System
{
    class Program
    {
        int EmpId;
        string EmpName;
        DateTime DOJ;
        double Salary;

        void Add1()
        {
            Console.WriteLine("Enter employee id");
             EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter employee name");
            EmpName = (Console.ReadLine());
            Console.WriteLine("Enter employee DOJ");
            DOJ = DateTime.Parse(ReadLine());

            Console.WriteLine("Enter employee salary");
            Salary = int.Parse(Console.ReadLine());
        }
        void Remove1()
        {
            Console.WriteLine("Enter EmpID");
            EmpId = int.Parse(ReadLine());
        }
        void Modify1()
        {
            Console.WriteLine("Enter employee id");
            EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter employee name");
            EmpName = Console.ReadLine();
            Console.WriteLine("Enter employee DOJ");
            DOJ = DateTime.Parse(ReadLine());

            Console.WriteLine("Enter employee salary");
            Salary = int.Parse(Console.ReadLine());
        }
        
        static void Main(string[] args)
        {
           
            Program prog = new Program();
            Console.WriteLine("Enter selection as per 1.insert, 2.update, 3.delete");
            int choice = int.Parse(ReadLine());

            try
            {
                EmployeeBAL employeeBAL = new EmployeeBAL();
           
            Employee entities = new Employee { EmpId = prog.EmpId, EmpName = prog.EmpName, DOJ = prog.DOJ, Salary = prog.Salary };
            switch (choice)
            {
                case 1:prog.Add1(); employeeBAL.Add(entities); WriteLine("Inserted...");break;
                case 2:prog.Modify1(); employeeBAL.Modify(entities); WriteLine(" Modified ....");break;
                case 3: prog.Remove1(); employeeBAL.Remove(prog.EmpId); WriteLine("Deelted ...."); break;
                default: WriteLine("Invalid Choice..."); break;
            }
            
                
                List<Employee> employees = employeeBAL.GetAll();
                foreach (var item in employees)
                {
                    Console.WriteLine(item); // EMS_Entities.Employee
                }



               
                //----------------------------------

                // emp = new Employee
                //{
                //    EmpId = 1002,
                //    DOJ = DateTime.Now.AddDays(-2),
                //    Salary = 12000,
                //    EmpName = "Ambedkar"
                //};
                //employeeBAL.Add(emp);
                //Console.WriteLine("Updated..");
                // employees = employeeBAL.GetAll();
                //foreach (var item in employees)
                //{
                //    Console.WriteLine(item); // EMS_Entities.Employee
                //}
            }
            catch(EmployeeValidationException ex3)
            {
                Console.WriteLine(ex3.Message);
            }
            catch(EmployeeNotFoundException ex4)
            {
                Console.WriteLine(ex4.Message);
            }
            catch(Exception ex5)
            {
                Console.WriteLine(ex5.Message);
            }

            Console.ReadKey();
        }
        
    };
}
//=========================
