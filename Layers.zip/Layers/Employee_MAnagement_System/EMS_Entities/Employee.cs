﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Entities
{
    public class Employee
    {

        public int EmpId { get; set; }
        public string EmpName { get; set; } // Should not contain Digits
        public double Salary { get; set; }
        public DateTime DOJ { get; set; }

        public override string ToString()
        {
            return $"{EmpId}{EmpName}{Salary}{DOJ}";
        }
    }
}
