﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personclass
{
    class Person
    {
        //properties for a Person
        private int id;
        public int Id{ get; set;}
        private string name;
        public string Name { get; set; }
        private int age;
        public int Age { get; set; }
        private DateTime dob;
        public DateTime DOB { get; set; }

        // creating a Parameterised constructor

        public Person(int Id, String Name, int Age, DateTime DOB)
        {
            id = Id;
            name = Name;
            age = Age;
            dob = DOB;
        }
        //Creating Default Constructor 

        public Person()
        {

        }
        //Creating Method For Displaying The Details
        public void DisplayDetails()
        {
            Console.WriteLine($"Person ID:{Id}");
            Console.WriteLine($"Person Name:{Name}");
            Console.WriteLine($"Person Age:{Age}");
            Console.WriteLine($"Person DOB:{DOB}");
        }
    }
    


    public class Example
    {
        public static void Main()
       
        private static void GetPropertyValues(Object obj)
        {
            Type t = obj.GetType();
            Console.WriteLine("Type is: {0}", t.Name);

            // here we are using propertyinfo

            PropertyInfo[] props = t.GetProperties(Address, city);
            foreach (var prop in props)
                if (prop.GetIndexParameters().Length == 0)
                    Console.WriteLine(" {0} ({1}): {2}", prop.Name, prop.PropertyType.Name, prop.GetValue(obj));
                else
                    Console.WriteLine(" {0} ({1}): <Indexed>", prop.Name, prop.PropertyType.Name);

        }
        
    }
   
}