﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities; //Reference to Entities library
using PMS_Exceptions; //Reference to Exceptions library
using System.Runtime.Serialization.Formatters.Binary; 
using System.IO;


namespace PMS_DAL
{
   //Function to perform CRUD Operations
    public class ProductDAL
    {
        //Creating a collection
     public static  List<Product> products = new List<Product>();


        public List<Product> SelectAll()
        {
            return products;
        }


        //Function to Insert the Product record
        public void Insert(Product product)
        {

            try
            {
                products.Add(product); 
                Console.WriteLine("Added");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //Update
        //public void Update(Product product)
        //{
        //    try
        //    {
        //        for (int i = 0; i < products.Count; i++)
        //        {
        //            if(products[i].Id == product.Id)
        //            {
        //                products[i].Name = product.Name;
        //                products[i].Price = product.Price;
        //                products[i].ExpDate = product.ExpDate;
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        //Function to Update the Product details
        public void Update(Product product)
        {
            try
            {
                //using LINQ Expression
                //var prd = (from p in products
                //          where p.Id == product.Id
                //          select p).SingleOrDefault();
                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                //using extension method & lambda
                if (product != null)
                {
                    var prd = products.SingleOrDefault(p => p.Id == product.Id);
                    prd.Name = product.Name;
                    prd.Price = product.Price;
                    prd.ExpDate = product.ExpDate;
                    Console.WriteLine("Updated");
                }
                else
                {
                    throw new ProductNotFoundException("product with Id: " + product.Id + "Not Found");
                }
            }
            catch (ProductNotFoundException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
        }

        public void Store(List<Product> prods)
        {
            products = prods;

        }


        //Function to Delete Product record based on Id 
        public void Delete( int Id)
        {
            try
            {

                //var prd = products.SingleOrDefault(p => p.Id == Id);
                var prd = products.SingleOrDefault(p => p.Id == Id);
                if(prd!=null)
                {
                    products.Remove(prd);
                    Console.WriteLine("Deleted");
                }
                else
                {
                    throw new ProductNotFoundException("product with Id: " + Id + "Not Found");
                }

            }
            catch (ProductNotFoundException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }


        

        //Function to Search product based on Id 
        public Product Search(int Id)
        {

            var prd = products.SingleOrDefault(p => p.Id == Id);
            return prd; 
        }

        //Function to Serialize the Data
        public static void SerializeData()
        {
            
            FileStream stream;
            try
            {
                stream = new FileStream(@"C:\Users\mukhem\Desktop\ProductManagementSystem\Product.txt", FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, products);
                stream.Close();
              
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        //Function to Deserialize the data
        public static List<Product> DeSerializeData()
        {
            FileStream stream;
            try
            {
               
                stream = new FileStream(@"C:\Users\mukhem\Desktop\ProductManagementSystem\Product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                BinaryFormatter formatter = new BinaryFormatter();
                 products= formatter.Deserialize(stream) as List<Product>;
                stream.Close();
                return products;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
