﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PMS_Exceptions
{
    [Serializable]
    public class ProductNotFoundException : Exception
    {
        //Parameterized constructor with message parameter
        public ProductNotFoundException(string message): base(message)
        {

        }
    }
}
