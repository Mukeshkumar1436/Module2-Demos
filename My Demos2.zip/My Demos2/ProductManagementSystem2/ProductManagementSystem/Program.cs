﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : 172435_mukhem
 * Desc                 : Program for product management system
 * Version              : 1.0
 * Last Modified Date   : 14-Mar-2019
 * Change Description   : Description on layers
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_BAL;  // Reference to BAL library
using PMS_Entities; //Reference to Entities library
using PMS_Exceptions; //Reference to Exception library
using System.IO;


namespace ProductManagementSystem
{
    class Program
    {
        static List<Product> prods;
        //Function to print Menu
        static int PrintMenu()
        {
            Console.WriteLine("=========Menu========\n1.Add Product\n2.Update Product\n3.Delete Product\n4.GetAll\n5.Search");
            Console.WriteLine("\nSelect your choice: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        //Creating a product
        static Product CreateProduct(int id)
        {
            Product product = new Product();
            product.Id = id;
            Console.WriteLine("enter product details");
            Console.Write("Name: ");
            product.Name = Console.ReadLine();
            Console.Write("Price: ");
            product.Price = double.Parse(Console.ReadLine());
            Console.Write("ExpDate: ");
            product.ExpDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Email: ");
            product.Email = Console.ReadLine();
            return product;
        }

        //Function to Diplay products using collection
        static void DisplayProducts(List<Product> prods)
        {
            foreach( var prd in prods)
            {
                Console.WriteLine(prd);
            }
        }


        static void Main(string[] args)
        {
            int count; ProductBAL productBAL = new ProductBAL(); 
            if (File.Exists(@"C:\Users\mukhem\Desktop\ProductManagementSystem\Product.txt"))
            {
                prods = ProductBAL.DeSerializeData();
                productBAL.Store(prods);

                if (prods.Count != 0)
                {
                    count = prods[prods.Count - 1].Id;
                }
                else { count = 100; }
            }
            else { count = 100; }
            try
                {
                
                
                string choice2;
                
                do
                {
                    int choice = PrintMenu();
                    Product product = null;
                    
                    int Id;
                    switch (choice)
                    {
                        case 1:
                            Id = ++count;
                            product = CreateProduct(Id);
                            productBAL.Add(product);
                            Console.WriteLine("Product Inserted..");
                            break;
                        case 2:
                            Console.WriteLine("Enter Product Id");
                            Id = int.Parse(Console.ReadLine());
                            product = CreateProduct(Id);                           
                            productBAL.Update(product);
                            break;
                        case 3:
                            Console.WriteLine("Enter Id of product to be deleted");
                            Id = int.Parse(Console.ReadLine());
                            productBAL.Delete(Id);
                            
                            break;
                        case 4:
                            prods = productBAL.GetAll();
                            DisplayProducts(prods);
                            break;
                        case 5:
                            Console.WriteLine("Enter Id of product to be Searched");
                            Id = int.Parse(Console.ReadLine());
                            product = productBAL.Search(Id);
                            Console.WriteLine(product);
                            break;
                    }
                    ProductBAL.SerializeData();
                   
                    Console.WriteLine("Enter 'y' for continue; Any letter for exit");
                    choice2 = Console.ReadLine();
                }

                while (choice2 == "y");
                Console.WriteLine("Thank you");
                }
                catch (ProductNotFoundException ex3)
                {
                    Console.WriteLine(ex3.Message);
                    
                }
                catch (ProductValidationException ex4)
                {
                    Console.WriteLine(ex4.Message);
                }
                catch (Exception ex5)
                {
                    Console.WriteLine(ex5.Message);
                }            
            Console.ReadKey();
        }
    }
}
