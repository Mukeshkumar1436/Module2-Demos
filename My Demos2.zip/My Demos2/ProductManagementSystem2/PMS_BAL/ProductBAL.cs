﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_DAL; //Reference to DAL Library
using PMS_Entities; //Reference to Entities Library
using PMS_Exceptions; //Reference to Exceptions Library
using System.Text.RegularExpressions;

namespace PMS_BAL
{
    
    public class ProductBAL
    {
        
        
        ProductDAL productDAL = new ProductDAL();

        //Validations 
        public bool IsValid(Product product)
        {
            bool valid = true;
            StringBuilder stringBuilder = new StringBuilder();

            if (!Regex.IsMatch(product.Email, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
            {
                valid = false;
                stringBuilder.Append("this is inavlid email address!" + Environment.NewLine);

            }
            if(product.ExpDate <=  DateTime.Now)
            {
                valid = false;
                stringBuilder.Append("Incorrect Date!" + Environment.NewLine);
            }

            if ((product.Price < 100) || (product.Price> 50000))
            {
                stringBuilder.Append("price is in the range of 100 to 50000!" + Environment.NewLine);
                valid = false;
            }

            if (!valid)
            {
                throw new ProductValidationException(stringBuilder.ToString());
            }

            return valid;
        }
       
        public List<Product> GetAll()
        {
            return productDAL.SelectAll();
        }

        //Insert
        public void Add(Product product)
        {
            try
            {
                if (IsValid(product))
                {

                    productDAL.Insert(product);
                }
            }
            catch (ProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        //Update
        public void Update(Product product)
        {
            try
            {
                if (IsValid(product)&& Isexisted(product.Id))
                {

                    productDAL.Update(product);
                }
            }
            catch(ProductNotFoundException ex)
            {
                throw ex;
            }
            catch (ProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        private bool Isexisted(int id)
        {
            try
            {
                foreach (Product pro in ProductDAL.products)
                {
                    if (id == pro.Id)
                    {
                        return true;
                    }
                }
                throw new ProductNotFoundException ("product is not existed");
            }
            catch(ProductNotFoundException ex)
            {
                throw ex;
            }
        }

        public void Store(List<Product> prods)
        {
            productDAL.Store(prods);
        }

        //Delete
        public void Delete(int Id)
        {
            try
            {
                if (Isexisted(Id))
                { productDAL.Delete(Id); }

                else { throw new ProductNotFoundException("id is not existed"); }
            }
            catch(ProductNotFoundException ex)
            {
                throw ex;
            }
            catch (ProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        //Search
        public Product Search(int Id)
        {
            try
            {
                if (Isexisted(Id))
                { return productDAL.Search(Id); }

                else { throw new ProductNotFoundException("id is not existed"); }
            }
            catch (ProductNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }
            //Serialize
        public static void SerializeData()
        {
            ProductDAL.SerializeData();
        }

        //Deserialize
        public static List<Product> DeSerializeData()
        {
            return ProductDAL.DeSerializeData();
        }
    }

}

//extra validations:
//// if ((doctor.RegNo < 101) || (doctor.RegNo > 99999))  // 101-99999
//            {
//                sb.Append("EmpId should be in range of 101 & 99999!" + Environment.NewLine);
//                valid = false;
//            }
//            if (!Regex.IsMatch(doctor.DoctName, @"^[\p{L} \.\-]+$"))
//            {
//                sb.Append("DoctName should not ontain Digits" + Environment.NewLine);
//                valid = false;
//            }
//            if(doctor.AreaofSpecialisation!="Ortho" || doctor.AreaofSpecialisation!="heartspecialist")
//            {
//                sb.Append("Area od Specialization should be like Ortho, " + Environment.NewLine);
//                valid = false;
//            }
//            if (doctor.ContactNo.Length != 10 && (doctor.ContactNo[0] !=6 || doctor.ContactNo[0] != 7 || doctor.ContactNo[0] != 8))
//            {
//                sb.Append("Contact No Must Stats with 6,7,8 , " + Environment.NewLine);
//                valid = false;
//            }
