﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS_DAL;
using EMS_Entities;
using EMS_Exceptions;


namespace EMS_BAL
{
    public class EmployeeBAL
    {
        EmployeeDAL employeeDAL = new EmployeeDAL();

        public bool IsValid(Employee employee)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if ((employee.EmpId < 101) || (employee.EmpId > 99999))  // 101-99999
            {
                sb.Append("EmpId should be in range of 101 & 99999!" + Environment.NewLine);
                valid = false;
            }
            if (!Regex.IsMatch(employee.EmpName, @"^[\p{L} \.\-]+$"))
            {
                sb.Append("EmpName should not ontain Digits" + Environment.NewLine);
                valid = false;
            }

            if (employee.DOJ > DateTime.Now)
            {
                sb.Append("DOJ is always past Date");
                valid = false;
            }

            if (!valid)
            {
                throw new EmployeeValidationException(sb.ToString());
            }
            return valid;
        }

        public void Add(Employee employee)
        {
            try
            {
                if (IsValid(employee))
                {

                    employeeDAL.Insert(employee);
                }
            }
            catch (EmployeeValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        public void Modify(Employee employee)
        {
            try
            {
                if (IsValid(employee))
                {

                    employeeDAL.Update(employee);
                }
            }
            catch (EmployeeValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        public void Remove(int empId)
        {
            try
            {
                employeeDAL.Delete(empId);

            }
            catch (EmployeeValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }
        public List<Employee> GetAll()
        {
            return employeeDAL.SelectAll();
        }
    }
}