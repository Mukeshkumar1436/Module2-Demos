﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exceptions;

namespace EMS_DAL
{
    public class EmployeeDAL
    {
        List<Employee> employees = new List<Employee>();

        // Inserting 
        public void Insert(Employee employee)
        {
            try
            {
                employees.Add(employee);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        // Updating
        public void Update(Employee employee)
        {
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employees[i].EmpId == employee.EmpId)
                    {
                        employees[i].EmpName = employee.EmpName;
                        employees[i].Salary = employee.Salary;
                        employees[i].DOJ = employee.DOJ;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        //Deleting
        public void Delete(int empid)
        {
            bool isDeleted = false;
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employees[i].EmpId == empid)
                    {
                        // employees.Remove(employees[i]);
                        employees.RemoveAt(i);
                        isDeleted = true;
                        break;
                    }
                }
                if (!isDeleted)
                {
                    throw new EmployeeNotFoundException("Not Found!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<Employee> SelectAll()
        {
            return employees;
        }
    }
}