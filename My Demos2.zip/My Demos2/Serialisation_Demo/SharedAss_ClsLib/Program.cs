﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace SharedAss_ClsLib
{
    class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Enter the path: ");
            string path = Console.ReadLine();
            Assembly assembly = Assembly.LoadFrom(path);
            Type[] types = assembly.GetTypes();
            foreach (Type t in types)
            {
                Console.WriteLine(t.FullName);
            }
            Console.ReadKey();
        }

    }

}