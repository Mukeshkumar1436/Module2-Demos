using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clslib_Calculator;

namespace Demo_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            Console.WriteLine("enter first number: ");
            int n1 = int.Parse(Console.ReadLine());
            Console.Write("enter second number: ");
            int n2 = int.Parse(Console.ReadLine());
            int res = calculator.Add(n1, n2);
            Console.WriteLine("Result is: "+res);


            Console.WriteLine("Hi");

            Console.ReadKey();
        }
    }
}
