﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Project
    {
       private string name;
       public string Name { get; set; }
       private int id;
       public int Id { get; set; }
       private string projectname;
       public string ProjectName { get; set; }


        // creating a constructor

        public Project(String Name, int Id, string ProjectName)
            {
            name = Name;
            id = Id;
            projectname = ProjectName;      
            }


        //Creating Method For Displaying The Details
        public void DisplayDetails()
        {
            
            Console.WriteLine($"employee Name:{Name}");
            Console.WriteLine($"employee id:{Id}");
            Console.WriteLine($"employee projectname:{ProjectName}");
        }

    }
}
