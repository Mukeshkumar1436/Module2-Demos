﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Program
    {   
        public class StringOperations
        {
            public static int SearchPosition(string input, char searchCriteria)
            {
                int index = input.IndexOf(searchCriteria);
                return index;
            }
        }
    }
}
