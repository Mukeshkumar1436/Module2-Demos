﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities;
using PMS_Exceptions;


namespace PMS_DAL
{
    public class ProductDAL
    {
        List<Product> products = new List<Product>();


        public List<Product> SelectAll()
        {
            return products;
        }


        //Insert
        public void Insert(Product product)
        {

            try
            {
                products.Add(product);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //Update
        //public void Update(Product product)
        //{
        //    try
        //    {
        //        for (int i = 0; i < products.Count; i++)
        //        {
        //            if(products[i].Id == product.Id)
        //            {
        //                products[i].Name = product.Name;
        //                products[i].Price = product.Price;
        //                products[i].ExpDate = product.ExpDate;
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        //linq
        public void Update(Product product)
        {
            try
            {
                //using LINQ Expression
                //var prd = (from p in products
                //          where p.Id == product.Id
                //          select p).SingleOrDefault();
                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                //using extension method & lambda
                if (product != null)
                {
                    var prd = products.SingleOrDefault(p => p.Id == product.Id);
                    prd.Name = product.Name;
                    prd.Price = product.Price;
                    prd.ExpDate = product.ExpDate;
                }
                else
                {
                    throw new ProductNotFoundException("product with Id: " + product.Id + "Not Found");
                }
            }
            catch (ProductNotFoundException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
        }


        //Delete
        public void Delete( int Id)
        {
            try
            {

                //var prd = products.SingleOrDefault(p => p.Id == Id);
                var prd = products.SingleOrDefault(p => p.Id == Id);
                if(prd!=null)
                {
                    products.Remove(prd);
                }
                else
                {
                    throw new ProductNotFoundException("product with Id: " + Id + "Not Found");
                }

            }
            catch (ProductNotFoundException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }


        

            //Search
            public Product Search(int Id)
        {
            var prd = products.SingleOrDefault(p => p.Id == Id);
            return prd;
        }
    }
}
