﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_Entities
{
    
    public class Product
    {
        static int count = 100;
        public Product()
        {
            count++;
            Id = count;
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public DateTime ExpDate{ get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
             return $"Id: {Id}{Environment.NewLine} Name: {Name}{Environment.NewLine} Price: {Price}{Environment.NewLine} ExpDate: {ExpDate}{Environment.NewLine} Email: {Email}";
           
        }
    }
}
