﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : 172435_mukhem
 * Desc                 : Program for product management system
 * Version              : 1.0
 * Last Modified Date   : 14-Mar-2019
 * Change Description   : Description on layers
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_BAL;
using PMS_Entities;
using PMS_Exceptions;


namespace ProductManagementSystem
{
    class Program
    {
        static int PrintMenu()
        {
            Console.WriteLine("=========Menu========\n1.Add Product\n2.Update Product\n3.Delete Product\n4.GetAll\n5.Search");
            Console.WriteLine("\nSelect your choice: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static Product CreateProduct()
        {
            Product product = new Product();
            Console.WriteLine("enter product details");
            Console.Write("Name: ");
            product.Name = Console.ReadLine();
            Console.Write("Price: ");
            product.Price = double.Parse(Console.ReadLine());
            Console.Write("ExpDate: ");
            product.ExpDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Email: ");
            product.Email = Console.ReadLine();
            return product;
        }

        static void DisplayProducts(List<Product> prods)
        {
            foreach( var prd in prods)
            {
                Console.WriteLine(prd);
            }
        }
        static void Main(string[] args)
        {
           
              
                try
                {
                    ProductBAL productBAL = new ProductBAL();
                string choice2;

                do
                {
                    int choice = PrintMenu();
                    Product product = null;
                    List<Product> prods;
                    int Id;
                    switch (choice)
                    {
                        case 1:
                            product = CreateProduct();
                            productBAL.Add(product);
                            Console.WriteLine("Product Inserted..");
                            break;
                        case 2:
                            product = CreateProduct();
                            Console.WriteLine("Enter Product Id");
                            product.Id = int.Parse(Console.ReadLine());
                            productBAL.Update(product);
                            break;
                        case 3:
                            Console.WriteLine("Enter Id of product to be deleted");
                            Id = int.Parse(Console.ReadLine());
                            productBAL.Delete(Id);
                            break;
                        case 4:
                            prods = productBAL.GetAll();
                            DisplayProducts(prods);
                            break;
                        case 5:
                            Console.WriteLine("Enter Id of product to be Searched");
                            Id = int.Parse(Console.ReadLine());
                            product = productBAL.Search(Id);
                            Console.WriteLine(product);
                            break;
                    }
                    Console.WriteLine("y or n");
                    choice2 = Console.ReadLine();
                }

                while (choice2 != "n");
            }
                catch (ProductNotFoundException ex3)
                {
                    Console.WriteLine("Product details not found");
                    throw ex3;
                }
                catch (ProductValidationException ex4)
                {
                    Console.WriteLine(ex4.Message);
                }
                catch (Exception ex5)
                {
                    Console.WriteLine(ex5.Message);
                }
               
            Console.WriteLine("you are not allowed to enter the details if you want to do the oepration run the aplication again");

            Console.ReadKey();

        }
    }
}
