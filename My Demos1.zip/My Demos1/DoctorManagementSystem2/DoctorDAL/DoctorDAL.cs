﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_Entities;
using DMS_Exceptions;
using System.Runtime.Serialization.Formatters.Binary;


namespace DMS_DAL
{
    public class DoctorDAL
    {
       
        //Insert
        public static List<Doctor> doctors = new List<Doctor>();
        public bool AddDoctorDAL(Doctor doctor)
        {
            bool doctorAdded = false;
            try
            {
                doctors.Add(doctor);
                doctorAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return doctorAdded;
        }

        //update
        public void Update(Doctor doctor)
        {
            try
            {
                for (int i = 0; i < doctors.Count; i++)
                {
                    if (doctors[i].RegNo == doctor.RegNo)
                    {
                        doctors[i].DoctName = doctor.DoctName;
                        doctors[i].AreaofSpecialisation = doctor.AreaofSpecialisation;
                        doctors[i].City = doctor.City;
                        doctors[i].ClinicAddress = doctor.ClinicAddress;
                        doctors[i].ClinicTimings = doctor.ClinicTimings;
                        doctors[i].ContactNo = doctor.ContactNo;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //Delete
        public void Delete(int RegNo)
        {
            bool IsDeleted = false;
            try
            {
                for (int i = 0; i < doctors.Count; i++)
                {
                    if (doctors[i].RegNo == RegNo)
                    {
                        doctors.RemoveAt(i);
                        IsDeleted = true;
                        break;
                    }

                }
                if (!IsDeleted)
                {
                    throw new DoctorExceptionNotFound("not found");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Doctor> SelectAll()
            {
                return doctors;
            }
    }
}
