﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_BAL;
using DMS_Entities;
using DMS_Exceptions;

namespace DoctorManagementSystem
{
    class Program
    {
        public static void AddDoctor()
        {
            try
            {
                Doctor doctor = new Doctor();

                Console.WriteLine("Doctor's RegNo is :");
                doctor.RegNo = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the Doctor Name");
                doctor.DoctName = Console.ReadLine();

                Console.WriteLine("Enter the City name");
                doctor.City = Console.ReadLine();

                Console.WriteLine("Enter the Area Of Specialization ");
                doctor.AreaofSpecialisation = Console.ReadLine();

                Console.WriteLine("Enter the Clinic Address ");
                doctor.ClinicAddress = Console.ReadLine();

                bool doctorAdded = DoctorBAL.ADDDoctorBAL(doctor);
                if (doctorAdded == true)
                {
                    Console.WriteLine("Doctor added successfully");
                }
                else
                {
                    throw new Exception("Doctor not added successfully");

                }
                DoctorBAL.SerializeData();
            }
            catch
            {

            }
        }
            
        static void Main(string[] args)
        {
                       
        }
    }
}
