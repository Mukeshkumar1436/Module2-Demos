﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS_Exceptions
{
   public class DoctorValidationException : Exception
    {
        public DoctorValidationException(string errormessage): base(errormessage)
        {

        }
    }
}
