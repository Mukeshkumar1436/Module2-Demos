﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Doctor_Entities;
using Custom_Exceptions;

namespace DoctorDAL
{
    //DAL for CRUD operations
    public class DoctorDAL
    {
        List<Doctor> doctors = new List<Doctor>();

        //Inserting Doctor into collection
        public void Insert(Doctor doctor)
        {
            try
            {
                doctors.Add(Doctor);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Update(Doctor doctor)
        {
            employees.Add(employee);
        }

        public void Delete(Employee employee)
        {
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employee[i].EmpId = employee.EmpId) ;
                    {
                        //employee.remove(employee[i]);
                        employees.RemoveAt(i);
                        isDeleted = true;
                        break;

                    }
                }
                if (!isDeleted)
                {
                    throw new EmployeeNotFoundException("Employee not found");
                }

            }
            catch
            {

            }
            employees.Add(employee);
        }

        public List<Employee> SelectAll()
        {
            return employees;
        }
    }
}