﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doctor_Entities
{
    [Serializable]
    public class DoctorEntities
    {
        //Creating the property fields for the following
        public int RegistrationNo { get; set; }
        public string DoctorName { get; set; }
        public string City { get; set; }
        public char AreaofSpecialisation { get; set; }
        public char ClinicAddress { get; set; }
        public DateTime ClinicTimings { get; set; }
        public int ContactNo { get; set; }

    }
}
