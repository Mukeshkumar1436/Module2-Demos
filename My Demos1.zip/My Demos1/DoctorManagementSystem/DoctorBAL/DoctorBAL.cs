﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DMS_DAL;
using DMS_Entities;
using DMS_Exceptions;
using System.Text.RegularExpressions;

namespace DMS_BAL
{
    public class DoctorBAL
    {
        public static List<Doctor> doctors = new List<Doctor>();
        private static bool ValidateDoctor(Doctor doctor)
      
       
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if ((doctor.RegNo < 101) || (doctor.RegNo > 99999))  // 101-99999
            {
                sb.Append("EmpId should be in range of 101 & 99999!" + Environment.NewLine);
                valid = false;
            }
            if (!Regex.IsMatch(doctor.DoctName, @"^[\p{L} \.\-]+$"))
            {
                sb.Append("DoctName should not ontain Digits" + Environment.NewLine);
                valid = false;
            }
            if(doctor.AreaofSpecialisation!="Ortho" || doctor.AreaofSpecialisation!="heartspecialist")
            {
                sb.Append("Area od Specialization should be like Ortho, " + Environment.NewLine);
                valid = false;
            }
            if (doctor.ContactNo.Length != 10 && (doctor.ContactNo[0] !=6 || doctor.ContactNo[0] != 7 || doctor.ContactNo[0] != 8))
            {
                sb.Append("Contact No Must Stats with 6,7,8 , " + Environment.NewLine);
                valid = false;
            }
           
            if (!valid)
            {
                throw new DoctorExceptionNotFound(sb.ToString());
            }
            return valid;
        }

        public static bool AddDoctorBAL(Doctor newdoctor)
        {
            bool DoctorAdded = false;
            try
            {
                if (ValidateDoctor(newdoctor))
                {
                    DoctorDAL doctorDAL = new DoctorDAL();
                    DoctorAdded = doctorDAL.AddDoctorDAL(newdoctor);
                }
            }
            catch (DoctorExceptionNotFound ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return DoctorAdded;
        }

        public static bool Update(Doctor doctor)
        {
            bool DoctorUpdate = false;
            try
            {
                if (ValidateDoctor(doctor))
                {
                    DoctorDAL doctorDAL = new DoctorDAL();
                    DoctorUpdate = doctorDAL.AddDoctorDAL(doctor);

                }
            }
            catch (DoctorValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return DoctorUpdate;
        }

        public void Remove(int RegNo)
        {
            bool DoctorDeleted = false;
            try
            {
                if ((newdoctor)==doctors)
                {
                    DoctorDAL doctorDAL = new DoctorDAL();
                    doctorDAL.Delete(RegNo);
                }

            }
            catch (DoctorValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }

        }

        public bool existed(int Regno)
        {
            foreach(Doctor d in doctors)
            {
                if(d.RegNo == Regno)
                {

                }
               
                
            }
        }

        public List<Doctor> GetAll()
        {
            return doctorDAL.SelectAll();
        }
    }
}

