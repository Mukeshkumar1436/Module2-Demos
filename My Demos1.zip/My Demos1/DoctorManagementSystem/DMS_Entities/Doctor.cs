﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS_Entities
{
    [Serializable]
    public class Doctor
    {
        public int RegNo { get; set; }
        public String DoctName { get; set; }
        public string City { get; set; }
        public string ClinicAddress { get; set; }
        public string AreaofSpecialisation { get; set; }
        public DateTime ClinicTimings { get; set; }
        public string ContactNo { get; set; }
    }
}
