﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Custom_Exceptions
{

    [Serializable]
    public class DoctorException : Exception
    {
        public DoctorException() { }
        public DoctorException(string message) : base(message) { }
        public DoctorException(string message, Exception inner) : base(message, inner) { }
        protected DoctorException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}