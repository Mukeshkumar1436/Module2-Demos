﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatorDemo1
{
    class BankAccount
    {
        public int AccNo { get; set; }

        public double Balance { get; set; }

       

        public BankAccount(int accNo, double balance, NotificationsDelegate notifications)
        {
            this.AccNo = accNo;
            this.Balance = balance;
            this.notification = notification;
        }

        public void With(double amount)
        {
            if(Balance >= amount)
            {
                Balance -= amount;
            }
        }

        public void Depo(double amount)
        {
            Balance += amount;
        }
    }
}
