﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatorDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc calc = new Calc();

            //step-2: Creating Instance of Delegate
            CalcDelegate calDelegate = new CalcDelegate(calc.Add);
            calcDelegate += new CalcDelegate(calc.Sub);
            calcDelegate += new CalcDelegate(calc.Mult);


            //step-3: Invoking Delegate
            int res = calcDelegate(2, 3);
            Console.WriteLine("Result is : "+res);

            Console.ReadKey();
         
        }
    }
}
