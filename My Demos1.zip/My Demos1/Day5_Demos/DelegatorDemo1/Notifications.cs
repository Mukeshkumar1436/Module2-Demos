﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatorDemo1
{
    delegate void NotificationsDelegate(string message);

    class Notifications
    {
        public void SendSMS(string message)
        {
            //consider that this code is to send Message.
            Console.WriteLine(message);
        }

        public void SendMail(string message)
        {
            //consider that this code is to send Mail.
            Console.WriteLine(message);
        }

        public void SendVoice(string message)
        {
            //consider that this code is to send Voice.
            Console.WriteLine(message);
        }
    }
}
