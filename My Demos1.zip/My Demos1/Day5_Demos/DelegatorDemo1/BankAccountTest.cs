﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatorDemo1
{
    class BankAccountTest
    {
        static void Main(string[] args)
        {
            BankAccount bankAccount = new BankAccount(101, 10000);
            NotificationsDelegate notifiDel = new NotificationsDelegate(Notifications.SendMail);

            bankAccount.With(1000);
            //notifiDel("Balance Changed!")
            Console.ReadKey();
        }
    }
}
