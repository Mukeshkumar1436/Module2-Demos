﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace file
{
    class Program
    {


        static void Main(string[] args)    //main program start exection
        {
            try
            {
                Console.WriteLine("counting the number of words in the text file");

                Console.WriteLine("enter file name");

                string filename = Console.ReadLine();  // accepting user favour file name

                FileStream stream = File.Create($@"C: \Users\mukhem\Desktop\" + filename + ".txt");  //creating the file

                Console.WriteLine("enter data");
                string text1 = Console.ReadLine();

                stream.Close();   //close the file stream

                System.IO.File.WriteAllText($@"C: \Users\mukhem\Desktop\"+filename+".txt",text1);  //writing in that file


                string text2;

                //open the file
                var fileStream = new FileStream($@"C: \Users\mukhem\Desktop\" + filename + ".txt", FileMode.Open, FileAccess.Read);

                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
                {
                    text2 = streamReader.ReadToEnd();  //read the data from file to text2
                }

                int count = 0;

                foreach (char x in text2)
                {
                    if (x == ' ') count++;   //counting the number of words in the file
                }

                Console.WriteLine("Number of words in file :" + (++count));    //printing the number of words in the file

                //Giving file path to check if it exists 

                FileInfo fileObj = new FileInfo($@"C: \Users\mukhem\Desktop\" + filename + ".txt");
                if (fileObj.Exists)
                {
                    //If the file exists, what all we need to print

                    Console.WriteLine("File Name = {0}", fileObj.Name);
                    Console.WriteLine("File length in Bytes = {0}", fileObj.Length);
                    Console.WriteLine("File Extension = {0}", fileObj.Extension);
                    Console.WriteLine("File Full path = {0}", fileObj.FullName);
                    Console.WriteLine("File Directory = {0}", fileObj.DirectoryName);
                    Console.WriteLine("File Parent Directory = {0}", fileObj.Directory);
                    Console.WriteLine("File Creation Date and Time = {0}", fileObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Modified Date and Time = {0}", fileObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Last Access Date and Time = {0}", fileObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Attributes = {0}", fileObj.Attributes.ToString());
                }
                else
                {
                    //If the file doesnot exist then

                    Console.WriteLine("File does not Exists");
                }

                Console.WriteLine("--Thank You--");
            }

            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }

            Console.ReadLine();
        }
    }
}

