﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            int i;
            SupplierTest1 s1 = new SupplierTest1();
            do
            {
                Console.WriteLine("Enter a Number to Perform Operation:");
                Console.WriteLine("Enter 1 to AcceptDetails:");
                Console.WriteLine("Enter 2 to Perform Display Details");
                Console.WriteLine("Enter 3 to Exit:");




                i = Convert.ToInt32(Console.ReadLine());
                if (i == 1)
                    s1.AcceptDetails();
                else
                {
                    if (i == 2)
                        s1.DisplayDetails();
                }
            } while (i != 3);

        }
    }
}
