﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participant
{
    
 
    public class Participanty
    {
        Participanty p = new Participanty();
        public int EmpId {
            get {return EmpId; }
            set { EmpId = value; }
                         }
        public string Name {
            get {return Name; }
            set {Name=value; }
        }
        static string CompanyName;
        public int FoundationMarks
        {
            get {return FoundationMarks; }
            set{FoundationMarks=value;}
        }
        public int WebBasicMarks
        {
            get {return WebBasicMarks; }
            set {WebBasicMarks = value; }
        }
        public int DotNetMarks
        {
            get {return DotNetMarks; }
            set{DotNetMarks=value;}
        }
        private int ObtainedMarks;
        private double Percentage;
        
        public Participanty()
        {

            int TotalFoundationMarks = 100;
            int TotalWebBasicMarks = 100;
            int TotalDotNetMarks = 100;
            
        }
        static int TotalMarks;
        public Participanty(int EmpId,string Name,int FoundationMarks,int WebBasicMarks, int DotNetMarks)
        {
            this.EmpId = EmpId;
            this.Name = Name;
            this.FoundationMarks = FoundationMarks;
            this.WebBasicMarks = WebBasicMarks;
            this.DotNetMarks = DotNetMarks;

        }
        static Participanty()
        {
            CompanyName = "Coorprate university";
            TotalMarks = 300;
        }
        public int TotalM()
        {
            ObtainedMarks = FoundationMarks + WebBasicMarks + DotNetMarks;
            return ObtainedMarks;
        }
        
        public double DisplayPercentage() {

            Percentage =( ((double)ObtainedMarks) / ((double)TotalMarks))*100;
            Console.WriteLine("hi");
            return Percentage;
        }
    }
}
