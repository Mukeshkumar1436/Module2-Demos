﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArthmeticLibrary
{
    public class ArthmeticOperations
    {
        public  void Add(int n1, int n2)
        {
            Console.WriteLine($"{n1}+{n2}={(n1 + n2)}");
        }
        public void Sub(int n1, int n2)
        {
            Console.WriteLine($"{n1}-{n2}={(n1 - n2)}");
        }
        public void Mul(int n1, int n2)
        {
            Console.WriteLine($"{n1}*{n2}={(n1 * n2)}");
        }
        public void Div(int n1, int n2)
        {
            Console.WriteLine($"{n1}/{n2}={(n1 / n2)}");
        }
        public void Mod(int n1, int n2)
        {
                Console.WriteLine($"{n1}%{n2}={(n1 % n2)}");
        }

        public void Add(double n1, double n2)
        {
            Console.WriteLine($"{n1}+{n2}={(n1 + n2)}");
        }
        public void Sub(double n1, double n2)
        {
            Console.WriteLine($"{n1}-{n2}={(n1 - n2)}");
        }
        public void Mul(double n1, double n2)
        {
            Console.WriteLine($"{n1}*{n2}={(n1 * n2)}");
        }
        public void Div(double n1, double n2)
        {
            Console.WriteLine($"{n1}/{n2}={(n1 / n2)}");
        }
        public void Mod(double n1, double n2)
        {
            Console.WriteLine($"{n1}%{n2}={(n1 % n2)}");
        }



    }
}
