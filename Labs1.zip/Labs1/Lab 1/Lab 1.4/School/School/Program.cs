﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School
{
    class Program
    {
        
        public int roll{ get; set; }
        
        public string name { get; set; }
        
        public byte age { get; set; }
        
        public char gender { get; set; }
        
        public DateTime dateOfBirth { get; set; }
        
        public string address { get; set; }
        
        public Single percentage { get; set; }


        static void Main(string[] args)
        {
            Console.WriteLine("enter number students in the school:");
            int k = Convert.ToInt32(Console.ReadLine());
            Program[] p = new Program[k];
            for (int i = 0; i < k; i++)
            {
                p[i] = new Program();
                Console.Write("enter student RollNumber:");
                p[i].roll = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter student Name:");
                p[i].name = Console.ReadLine();
                Console.Write("enter student Age:");
                p[i].age = Convert.ToByte(Console.ReadLine());
                Console.Write("enter Gender:");
                p[i].gender = Convert.ToChar(Console.ReadLine());
                Console.Write("enter student DateOfBirth:");
                p[i].dateOfBirth = Convert.ToDateTime(Console.ReadLine());
                Console.Write("enter student Address:");
                p[i].address = Console.ReadLine();
                Console.Write("enter student Percentage:");
                p[i].percentage = Convert.ToSingle(Console.ReadLine());
            }
            Console.WriteLine("==============================");

            Console.WriteLine("Students details are: ");
            for (int i = 0; i < k; i++)
            {
                Console.WriteLine($"Student RollNumber is: {p[i].roll}");
                
                Console.WriteLine($"Student Name is:    {p[i].name}");
                Console.WriteLine($"Student Age is:     {p[i].age}");
                Console.WriteLine($"Student Gender is:    {p[i].gender}");
                Console.WriteLine($"Student Address is:    {p[i].address}");
                Console.WriteLine($"Student DateOfBirth is:    {p[i].dateOfBirth}");
                Console.WriteLine($"Student Precentage is:   {p[i].percentage}");
                Console.WriteLine("=============================================");

            }
          
            Console.ReadKey();
        }
       
    }
   
}
