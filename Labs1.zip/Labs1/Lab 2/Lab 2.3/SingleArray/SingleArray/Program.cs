﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleArray
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("enter number of cities:");
            int n =Convert.ToInt32( Console.ReadLine());
            string[] arr = new string[n];
            Console.WriteLine("enter elements");
            for (int i = 0; i < n; i++)
            {

                arr[i] = Console.ReadLine();

            }
            Console.WriteLine("elements are:");
            foreach (var k in arr)
            {
                Console.WriteLine(k);

            }

        }
    }
}
