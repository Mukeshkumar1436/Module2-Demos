﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Principles_Demo.ISP //Interface Segregation principle
{
    //This principle states that any client should not be forced to use an interface which is irrelevant to it
    interface IDatabase
    {
        void Add(); 
    }

    interface IDB2
    {
        void Del();
    }

    public class Employee : IDatabase
    {
        public int Employee_Id { get; set; }
        public string Employee_Name { get; set; }

        public void Add()
        {
            //Code to add employee into db. 
        }       
    }

    public class Employee1 : IDatabase, IDB2
    {
        public int Employee_Id { get; set; }
        public string Employee_Name { get; set; }

        public void Add()
        {
            //Code to add employee into db. 
        }        
    }



}
